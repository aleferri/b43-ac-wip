#!/usr/bin/env python3
# sweep.py: diff the SROM sweep read-backs (~/re/dumps/wl/sweep/<v>/agc_<dev>.txt) against 'base'
import os, sys
D = os.path.expanduser('~/re/dumps/wl/sweep')
def load(v, dev):
    r = {}
    for l in open(f'{D}/{v}/agc_{dev}.txt'):
        p = l.split()
        if len(p) == 2: r['p' + p[0]] = p[1]
        elif len(p) == 3: r['t' + p[0]] = p[2]
    return r
vs = [v for v in sorted(os.listdir(D)) if v != 'base' and os.path.exists(f'{D}/{v}/agc_0001:01:00.0.txt')]
for dev, band in (('0001:01:00.0', '2g'), ('0002:01:00.0', '5g')):
    b = load('base', dev)
    print(f'== {band} base:', ' '.join(f'{k[1:]}={b[k]}' for k in sorted(b) if k[1:] in
          ('06dc','06dd','06de','06df','06e0','06e1','06e2','06e3','06e4','06e5','06ee','00f9','00fa','00fb')))
    for v in vs:
        x = load(v, dev); keys = open(f'{D}/{v}/keys.txt').read().split()
        d = [f'{k[1:]}:{b.get(k)}->{x[k]}' for k in sorted(x) if b.get(k) != x[k]]
        print(f'-- {v} [{" ".join(k for k in keys if k.startswith("0:" if band=="2g" else "1:"))}]')
        print('   ', ' '.join(d) if d else '(no change)')
