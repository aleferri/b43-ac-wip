RT-AC66U B1, DD-WRT r66396, wl 7.14.164.18: the AGC words wl programs, read back after changing one SROM rx-gain field.

wl reads the radios' SROM from NVRAM at attach (devpath prefixes 0: = 2.4 GHz radio, 1: = 5 GHz radio). For each
variant srom-sweep.sh set the keys in <variant>/keys.txt (keys_live.txt: as nvram read them back after the reboot),
committed, rebooted, let DD-WRT bring both radios up as APs (2.4 GHz ch 6/20, 5 GHz ch 36/80) and read back with
bcmpeek: PHY 0x?600-0x?7ff of cores 0-2 and PHY table 7 offsets 0xf0-0x1ff (agc_<pci>.txt: "<reg> <val>" and
"<off> <hi> <lo>"). Keys stay set from one variant to the next unless the next one sets them again; summary.txt
gives the values in force. The board's own values were restored afterwards (and checked against the NVRAM backup).

Board values: 0:rxgains2gelnagaina0-2=6, 0:rxgains2gtrisoa0-2=13, 0:rxgains2gtrelnabypa0-2=1;
              1:rxgains5gelnagaina0-2=2, 1:rxgains5gtrisoa0/1/2=7/9/8, 1:rxgains5gtrelnabypa0-2=1.
The R7000 (router-data/r7000/nvram-radios.txt): 2.4 GHz elnagain 3, triso 7, trelnabyp 1.

summary.txt   0x?6dc-0x?6e5, 0x?6ee and table 7 0xf9 of core 0 for every variant
sweep-diff.txt  sweep.py: every register in the read ranges that differs from 'base', all cores
Observations, for the 2.4 GHz radio:
- r7k (elnagain 3, triso 7 on all three cores) gives 0x06dc-0x06e5 and 0x06ee exactly as the R7000's mmio-cold-2g6
  trace writes them (014a 0634 014a 0024 014a 0058 014a 0008 014a 0008, 0006): the words follow the SROM fields;
- changing only the a0 field moves the words of cores 1 and 2 too (sweep-diff.txt), so the core 0 field drives all;
- elnagain moves 0x06dc/0x06de (and with it 0x06dd/0x06df, 0x06e1/0x06e3/0x06e5, 0x06ee, table 7 0xf9);
  triso moves 0x06e1-0x06e5 and 0x06ee; trelnabyp 0 moves only 0x06dd (0x0624 -> 0x0714).
Other registers in sweep-diff.txt (0x?60e, 0x?6c0-0x?6c5, 0x?78x, ...) are calibration and noise results that
change from boot to boot as well; compare them against base with that in mind.
