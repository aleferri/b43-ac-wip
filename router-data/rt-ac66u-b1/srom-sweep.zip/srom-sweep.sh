#!/bin/bash
# srom-sweep.sh <name> [key=val ...]: under DD-WRT, set SROM NVRAM keys, reboot, read back AGC state of both
# radios into ~/re/dumps/wl/sweep/<name>/. Baseline keys from nvram_now.bin are restored by srom-restore.sh.
O="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5"
R="ssh $O root@192.168.2.1"; N=$1; shift; D=~/re/dumps/wl/sweep/$N; mkdir -p $D
printf '%s\n' "$@" > $D/keys.txt
S=""; for kv in "$@"; do S="$S nvram set '$kv';"; done
timeout 30 $R "$S nvram commit >/dev/null; (sleep 1; reboot) >/dev/null 2>&1 &"
sleep 75; for i in $(seq 1 40); do timeout 8 $R 'wl -i eth1 bssid >/dev/null && wl -i eth2 bssid >/dev/null' 2>/dev/null && break; sleep 5; done
sleep 20
cat ~/re/test/ddwrt-guard-router.sh | timeout 20 $R 'cat > /tmp/rg.sh; chmod +x /tmp/rg.sh; nohup /tmp/rg.sh >/dev/null 2>&1 &'
timeout 20 $R 'for k in '"$(printf '%s ' "$@" | sed 's/=[^ ]*//g')"'; do echo $k=$(nvram get $k); done' > $D/keys_live.txt
cat ~/re/tools/peek/bcmpeek | timeout 20 $R 'cat > /tmp/bcmpeek; chmod +x /tmp/bcmpeek'
for d in 0001:01:00.0 0002:01:00.0; do
	B=/sys/bus/pci/devices/$d/resource0
	timeout 60 $R "for c in 0 1 2; do /tmp/bcmpeek $B phy 0x\${c}600 0x\${c}7ff; done; /tmp/bcmpeek $B tbl07 0xf0 0x1ff" > $D/agc_$d.txt
done
echo "$N: $(wc -l < $D/agc_0001:01:00.0.txt)/$(wc -l < $D/agc_0002:01:00.0.txt) $(cat $D/keys_live.txt | tr '\n' ' ')"
