# RT-AC66U B1: the group key of a further BSS under wl 7.14 (2026-11-04)

`wl` 7.14.164.18 under DD-WRT r63734 on the 5 GHz radio (eth2), two WPA2-PSK (CCMP) BSSes set up by DD-WRT's own
configuration (`wl1` "AC66UB1-wl-5g" and the virtual `wl1.1` "bf-test2", `wl1_vifs=wl1.1`, `restart wlconf`) and one
`nas` per BSS; a OnePlus Nord 2 joins bf-test2 (mark `phone-bss1`), the PC's rtl8821ae joins AC66UB1-wl-5g
(`pc-bss0`). `mbss2-full.bin` is the `wl-mmio-trap` capture from before the restart (`fsr_info_fn7=0x8057028c
init_mm_addr=0x80576c28`), `mbss2-ops.txt` its decode, `mbss2-readback.txt` the key index block (SHM `0x05e0`) and the
key table pointer (`0x0056`, `0x087a`) read back at the end.

In the key index block (entry n `(n << 4) | cipher`, AES 5) and the address match table (`sel=0x40000`, two words a
row, the flags in the high half of the second):

| when | entry | AMT row | what |
|---|---|---|---|
| `nas` starts on bf-test2 | 4: `0x0045`, material at `0x1134` | 0: address `00:00:00:00:00:00`, flags `0x8004` | bf-test2's group key |
| the phone joins bf-test2 | 5: `0x0055` | 1: the phone's address, `0x8004` | the phone's pairwise key |
| the PC joins AC66UB1-wl-5g | 1: `0x0015`, material at `0x1104` | - | AC66UB1-wl-5g's group key, key ID 1 |
| the PC joins AC66UB1-wl-5g | 6: `0x0065`, material at `0x1154` | 2: the PC's address, `0x8004` | the PC's pairwise key |

So the group key of the first BSS goes to the group entries by key ID, and that of a further BSS to the next free
per-row entry, its row marked with the zero address. bf-test2's own address (`06:d9:f5:19:b8:e0`) is at SHM
`0x06e8`-`0x06ec`.

`mbss-gk-test.sh`: b43 with the same (aleferri/b43-ac-wip, "group keys of further APs") on OpenWrt, two WPA2 SSIDs on
the 5 GHz radio: mac80211 has both BSSes' group keys in hardware (`hw_key_idx` 1 and 2 for the first, 4 and 5 for the
second) and the router's ARP broadcasts reach a station on the second SSID.
