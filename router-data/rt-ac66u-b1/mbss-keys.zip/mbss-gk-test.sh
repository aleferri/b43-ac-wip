#!/bin/bash
# mbss-gk-test.sh <b43.ko>: group keys of a further AP on the RT-AC66U B1. Loads the module, then the PC (rtl8821ae)
# joins the second 5 GHz SSID AC66UB1-b43-5g-b (WPA2, network wtest); the router flushes its neighbour entry and pings
# the PC (the ARP request is a broadcast under that BSS's group key), and pings the subnet broadcast; mac80211's debugfs
# lists the keys of both interfaces with their hardware index. Under 140 s on the test SSID (wifi-guard).
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@192.168.2.1"
KO=$1; K=$(cat ~/re/test/ap_psk)
ARGS="" ~/re/test/router-try-module.sh $KO | tail -1; $R 'touch /tmp/b43-keep'
for i in $(seq 1 30); do $R 'iw dev | grep -q "ssid AC66UB1-b43-5g-b"' && break; sleep 3; done
$R 'iw dev | grep -E "Interface|ssid"'
nmcli con delete mbsstest >/dev/null 2>&1
nmcli con add type wifi ifname wlp5s0 con-name mbsstest autoconnect no ssid AC66UB1-b43-5g-b ipv4.method manual ipv4.addresses 192.168.3.11/24 ipv4.never-default yes ipv6.method disabled wifi-sec.key-mgmt wpa-psk wifi-sec.psk "$K" >/dev/null
timeout 60 nmcli --wait 45 con up mbsstest >/dev/null 2>&1; echo "pc join rc=$?"; sleep 3
timeout 60 $R 'ip neigh flush dev br-wtest 2>/dev/null; ping -c 10 -W 1 192.168.3.11 | tail -2;
	for k in /sys/kernel/debug/ieee80211/phy*/keys/*; do [ -f $k/hw_key_idx ] || continue; printf "  %s %s idx=%s hw=%s flags=%s\n" "$(basename $(dirname $(dirname $k)))" "$(cat $k/algorithm)" "$(cat $k/keyidx)" "$(cat $k/hw_key_idx)" "$(cat $k/flags | tr "\n" " ")"; done;
	B=/sys/bus/pci/devices/0001:01:00.0/resource0; [ -x /tmp/bcmpeek ] && { echo "keyidx: $(/tmp/bcmpeek $B shm 0x05e0 0x05f0 | cut -d" " -f2 | tr "\n" " ")"; }'
nmcli con down mbsstest >/dev/null 2>&1; nmcli con delete mbsstest >/dev/null 2>&1
nmcli --wait 40 con up "Auto PonyWorld 5G" >/dev/null 2>&1; nmcli --wait 20 con up "Ethernet connection 1" >/dev/null 2>&1
iw dev wlp5s0 link | sed -n 2p
