# RT-AC66U B1: radar types by DFS region, ETSI 5 and 6 (2026-11-04)

b43 with `CONFIG_B43_DFS` (aleferri/b43-ac-wip `radar-regions`), 5 GHz AP on ch 52/80, the country set on both
radios through UCI (hostapd sets it at start), the module loaded fresh for every run (`region_test.sh`). Pulses
from a HackRF One at 5270 MHz, gain 35, amp on, played in service after the 60 s availability check;
`patterns/` has every pulse sent (`radar_gen.py`, seed 1, 3 bursts).

| country (DFS region) | pattern | driver | AP |
|---|---|---|---|
| FI (ETSI) | ETSI 5, 0.7 us, PRFs 326/350 Hz, 10 pulses each | `radar: ETSI 5 pulses` | left ch 52 |
| FI (ETSI) | ETSI 6, 0.7 us, PRFs 604/796 Hz, 15 pulses each | `radar: ETSI 1 pulses` | left ch 52 |
| US (FCC) | ETSI 5, as above | none | stayed |
| US (FCC) | FCC 2, 1.5 us, PRI 218 us, 29 pulses | `radar: FCC 2 pulses` | left ch 52 |
| FI (ETSI), after US | FCC 4, 12.2 us, PRI 454 us, 12 pulses | none | stayed |
| FI (ETSI), FI already set at load | FCC 4, as above | none | stayed |
| US (FCC) | FCC 4, as above | `radar: FCC 4 pulses` | left ch 52 |

FCC 4 at 12.2 us and 454 us fits no ETSI type (wider than ETSI 1-3 take at that PRI, narrower than ETSI 4), so
it tells the ETSI types alone from all types; the last run shows the same burst on air is a radar to the FCC types.
`runs.txt` is the script's output: hostapd's DFS events and the driver's radar line.
