#!/bin/bash
# region_test.sh <country> <pattern.iq> [MHz]: the AC66U's 5 GHz AP on ch52/80 under <country> (both radios), with
# ~/re/test/b43-dfs-regions.ko loaded fresh (also clears the NOP of an earlier radar); waits for the CAC, plays the
# pattern in service (radar_tx.sh, gain 35, amp on) and reports the driver's radar line and hostapd's DFS events.
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@${ROUTER:-192.168.2.1}"
C=$1; F=$2; MHZ=${3:-5270}; m="rt-$C-$(basename $F .iq)-$(date +%s)"
echo "== $C $(basename $F) at $MHZ MHz: $(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["desc"])' $F.json)"
$R "uci set wireless.radio0.country=$C; uci set wireless.radio1.country=$C; uci set wireless.radio1.channel=52; uci set wireless.radio1.htmode=VHT80; uci commit wireless; logger -t dfs $m; echo $m > /dev/kmsg"
ARGS="" ~/re/test/router-try-module.sh ~/re/test/b43-dfs-regions.ko > /dev/null; $R 'touch /tmp/b43-keep'
for i in $(seq 1 40); do $R "logread | sed -n '/$m/,\$p' | grep -q -E 'DFS-CAC-COMPLETED|DFS-RADAR'" && break; sleep 5; done
$R "iw reg get | grep -m1 country; logread | sed -n '/$m/,\$p' | grep -E 'DFS-CAC-COMPLETED' | cut -c1-120; iw dev | grep -A6 AC66UB1-b43-5g | grep channel"
sleep 5
AMP=1 FORCE=1 ~/re/dfs/radar_tx.sh "$F" "$MHZ" 35 | grep -i -E 'refused|error|no hackrf' 
sleep 8
$R "logread | sed -n '/$m/,\$p' | grep -E 'DFS-RADAR|DFS-NEW' | cut -c1-140; dmesg | sed -n '/$m/,\$p' | grep 'radar:'; iw dev | grep -A6 AC66UB1-b43-5g | grep channel"
