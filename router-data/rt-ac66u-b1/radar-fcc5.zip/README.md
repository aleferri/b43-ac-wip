# RT-AC66U B1: chirped long pulses and FCC 5 in the radar FIFOs (2026-11-04)

b43 with `CONFIG_B43_DFS` (test build: `radar_log=2` logs every FIFO entry as
`b43-radar <fifo> <w0> <w1> <w2> <w3> lvl <level>` and reports nothing), 5 GHz AP on ch 52/80, country US. Pulses
from a HackRF One at 5270 MHz (gain 35, amp on) in service (`fifo_log_run.sh US ...`); each `.json` is every pulse
sent (`radar_gen.py`).

## `lp<width>-c<chirp>`: 6 pulses 1500 us apart

| pulse | entries a pulse | read |
|---|---|---|
| CW 50 / 75 / 100 us | 2 / 3 / 4 | parts 28.8 us apart: 27.0 us each, the rest in the last |
| chirped by 5, 10 or 20 MHz, 50 us | 1 | w2 7:0 250, w3 7:4 2: 50.0 us |
| chirped, 75 us | 1 | w2 7:0 119, w3 7:4 3: 23.8 us + 51.2 us = 75.0 us |
| chirped, 100 us | 1 | w2 7:0 244, w3 7:4 3: 48.8 us + 51.2 us = 100.0 us |

w3 bit 4 is bit 8 of the width; bit 5 is the bit set on every pulse (7:4 reads 2, or 3 with the width's bit 8). So a
chirped long pulse comes as one entry as long as it is. The 11.6 and 17.8 us that FCC 5's 63 and 69 us pulses read
in `radar-long.zip` are the same: 11.6 + 51.2 = 62.8, 17.8 + 51.2 = 69.0.

## `fcc5-s2` .. `fcc5-s5`: FCC 5 (KDB 905462 D02 Table 6)

8, 11, 11 and 17 bursts over 12 s of 1-3 pulses of 50-100 us, chirped by 6.4, 13.9, 9.5 and 8.8 MHz: one entry a
pulse, as long as the pulse.

## `idle-180`: nothing sent for 180 s

1573 entries in 42 of the 1200 polls. 40 polls hold 1 or 2 entries (short ones). Two polls are full, both FIFOs
at 383 entries: a carrier with nothing sent, as runs of 23-27 us parts 28.8 us apart and some long entries.

`test/radar/check.sh` replays these: FCC 5 is a radar with the FCC types, not with the ETSI types; the idle run and
the `lp` trains (one burst each) are not a radar.

## `inservice/`: the detector in service

The release build (`KO=... region_test.sh`, module reloaded for every run, 52/80): FCC 5 `fcc5-s2` and `fcc5-s3`
under US are `radar: FCC 5 pulses` and the AP leaves ch 52; `fcc5-s2` under FI is not a radar.
