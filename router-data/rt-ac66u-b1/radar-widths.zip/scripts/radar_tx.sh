#!/bin/bash
# radar_tx.sh <file.iq> <freq MHz> [tx vga gain dB, default 0]: play one radar pattern once through the HackRF.
# Guards: only 5250-5350 / 5470-5725 MHz; never within GUARD MHz of the band the main router (the PC's Wi-Fi)
# uses; the HackRF's RF amp stays off unless AMP=1; gain above 30 dB only with FORCE=1. Logged in tx.log.
set -e
F=$1; MHZ=$2; GAIN=${3:-0}; GUARD=${GUARD:-60}; LOG=$(dirname "$0")/tx.log
[ -f "$F" ] && [ -n "$MHZ" ] || { echo "usage: $0 file.iq freqMHz [gain]"; exit 2; }
in_band() { [ "$1" -ge 5250 ] && [ "$1" -le 5350 ] || { [ "$1" -ge 5470 ] && [ "$1" -le 5725 ]; }; }
in_band "$MHZ" || { echo "refused: $MHZ MHz is not in a radar band (5250-5350, 5470-5725)"; exit 1; }
# the main router's channel, as the PC's Wi-Fi sees it (center1 and width) while it is on PonyWorld;
# otherwise the last reading, if under an hour old (main-channel)
CACHE=$(dirname "$0")/main-channel; c1=; w=
if iw dev wlp5s0 link 2>/dev/null | grep -q "SSID: PonyWorld"; then
	info=$(iw dev wlp5s0 info 2>/dev/null)
	c1=$(echo "$info" | grep -o 'center1: [0-9]*' | awk '{print $2}'); w=$(echo "$info" | grep -o 'width: [0-9]*' | awk '{print $2}')
	[ -n "$c1" ] && [ -n "$w" ] && echo "$c1 $w" > "$CACHE"
elif [ -f "$CACHE" ] && [ $(( $(date +%s) - $(stat -c %Y "$CACHE") )) -lt 3600 ]; then
	read -r c1 w < "$CACHE"
fi
if [ -n "$c1" ] && [ -n "$w" ]; then
	lo=$((c1 - w / 2 - GUARD)); hi=$((c1 + w / 2 + GUARD))
	if [ "$MHZ" -ge "$lo" ] && [ "$MHZ" -le "$hi" ]; then
		echo "refused: $MHZ MHz is within $GUARD MHz of the main router's channel ($c1 MHz, $w MHz wide)"; exit 1
	fi
else
	echo "refused: the main router's channel is unknown (PC not on PonyWorld, no reading in the last hour)"; exit 1
fi
[ "$GAIN" -le 30 ] || [ "$FORCE" = 1 ] || { echo "refused: gain $GAIN dB > 30 (FORCE=1 to allow)"; exit 1; }
[ "$GAIN" -ge 0 ] && [ "$GAIN" -le 47 ] || { echo "refused: gain must be 0-47 dB"; exit 1; }
A=0; [ "$AMP" = 1 ] && A=1
hackrf_info >/dev/null 2>&1 || { echo "no HackRF found (hackrf_info)"; exit 1; }
echo "$(date '+%F %T') tx $(basename "$F") ${MHZ} MHz gain ${GAIN} amp ${A} (main router ${c1} MHz/${w})" >> "$LOG"
hackrf_transfer -t "$F" -f $((MHZ * 1000000)) -s 20000000 -b 15000000 -x "$GAIN" -a "$A" 2>&1 | grep -v -E "^\s*$|^[0-9.]+ MiB" | tail -3
