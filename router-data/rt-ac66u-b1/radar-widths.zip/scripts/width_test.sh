#!/bin/bash
# width_test.sh <htmode> <pulse MHz>: the AC66U's 5 GHz AP on ch52 at <htmode> (VHT20/VHT40/VHT80) with the DFS module
# already loaded: restart Wi-Fi (detached), wait for the CAC, read the radar block back, then play ETSI 1 at <pulse MHz>
# (radar_tx.sh, gain 35, amp on) and report the detection. The config goes back to ch36 VHT80 at the end.
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@${ROUTER:-192.168.2.1}"
HT=$1; MHZ=$2; m="wt-$HT-$(date +%s)"
$R "uci set wireless.radio1.channel=52; uci set wireless.radio1.htmode=$HT; uci commit wireless; logger -t dfs $m; start-stop-daemon -S -b -x /sbin/wifi"
for i in $(seq 1 40); do $R "logread | sed -n '/$m/,\$p' | grep -q -E 'DFS-CAC-COMPLETED|DFS-RADAR'" && break; sleep 5; done
sleep 8
$R "logread | sed -n '/$m/,\$p' | grep -E 'DFS-CAC-START|DFS-CAC-COMPLETED' | grep -v phy[0-9]*-ap0.*2437 | cut -c1-140; iw dev | grep -A6 AC66UB1-b43-5g | grep channel; B=/sys/bus/pci/devices/0001:01:00.0/resource0; P=/tmp/bcmpeek; for r in 025b 0250 0261 0262 0263 0255 025c 0264; do \$P \$B phy 0x\$r 0x\$r; done | tr '\n' ' '; echo; echo \$(\$P \$B shm 0x66 0x66) \$(\$P \$B shm 0x5e 0x5e)"
AMP=1 FORCE=1 "$(dirname "$0")/dfs_run.sh" "$m" "$(dirname "$0")/iq/etsi1.iq" "$MHZ" 35 | head -1
sleep 8
$R "logread | sed -n '/$m/,\$p' | grep -E 'DFS-RADAR|DFS-NEW' | cut -c1-120; dmesg | grep 'radar:' | tail -1; iw dev | grep -A6 AC66UB1-b43-5g | grep channel"
$R "uci set wireless.radio1.channel=36; uci set wireless.radio1.htmode=VHT80; uci commit wireless"
