#!/usr/bin/env python3
# TEST ONLY: log every radar FIFO entry and each poll's match result while radar_log=1.
import sys
p = sys.argv[1]; s = open(p).read()
old = "static void b43_phy_ac_radar_fifo(struct b43_wldev *dev, unsigned int fifo,\n\t\t\t\t  u16 level)\n{"
assert s.count(old) == 1
s = s.replace(old, "static int b43_radar_log;\nmodule_param_named(radar_log, b43_radar_log, int, 0644);\n\n" + old)
old = "\t\tif (i % 4 == 3)\n\t\t\tb43_radar_entry(&dev->phy.ac->radar, fifo, w);\n"
assert s.count(old) == 1
s = s.replace(old, "\t\tif (i % 4 == 3) {\n\t\t\tif (b43_radar_log)\n\t\t\t\tprintk(KERN_INFO \"b43-radar %u %04x %04x %04x %04x lvl %u\\n\", fifo, w[0], w[1], w[2], w[3], level);\n\t\t\tb43_radar_entry(&dev->phy.ac->radar, fifo, w);\n\t\t}\n")
old = "\tt = b43_radar_match(&ac->radar);\n"
assert s.count(old) == 1
s = s.replace(old, "\tif (b43_radar_log && (level0 || level1))\n\t\tprintk(KERN_INFO \"b43-radar poll lv %u %u n %u %u hist %u\\n\", level0, level1, ac->radar.nfifo[0], ac->radar.nfifo[1], ac->radar.n);\n" + old)
old = "\tif (t)\n\t\tb43info(dev->wl, \"radar: %s pulses\\n\", b43_radar_type_name(t));\n\treturn !!t;"
assert s.count(old) == 1, 'ret'
s = s.replace(old, "\tif (t)\n\t\tb43info(dev->wl, \"radar: %s pulses\\n\", b43_radar_type_name(t));\n\treturn t && b43_radar_log != 2;")
open(p, 'w').write(s); print('applied')
