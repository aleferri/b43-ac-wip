# RT-AC66U B1: the radar detector at 20, 40 and 80 MHz (2026-11-03)

RT-AC66U B1, 5 GHz radio (BCM4360 rev 3, femctrl 3), ch 52.

## `radar52-{20,40,80}-*`: wl with the radar on

`wl` 7.14.164.18 under DD-WRT r63734, reloaded cold, radar and 802.11h on (`WLC_SET_RADAR` 243,
`WLC_SET_SPECT_MANAGMENT` 244 through `wlx`), AP at 52/20, 52/40 and 52/80, no station
(`scripts/ddwrt-session2.sh`). `-full.bin` is the `wl-mmio-trap` capture (`fsr_info_fn7=0x8057028c
init_mm_addr=0x80576c28` for this build), `-ops.txt` its decode (`reverse-tools/mmio2ops.py`), `-readback.txt` PHY
0x0250-0x0264, SHM 0x005e-0x0066 and MACCTL read back on the running AP.

At every width `wl` writes the same block in the same order (after the bandwidth setup's own 0x0250/0x0261-0x0263):

    025b 0261 0262 0263 0250 0255 0256 025d 0259 025f, SHM 0x0066 0x0030, 025c 0260 0264, HOSTF1 bit 13

and the width-dependent values are:

| | 0x025b | 0x0250 | 0x0262 | 0x0263 | 0x0261 |
|---|---|---|---|---|---|
| 20 MHz | 0x0008 | 0xac19 | 0x00c8 | 0x0019 | 0 |
| 40 MHz | 0x0010 | 0xac32 | 0x0190 | 0x0032 | 0 |
| 80 MHz | 0x001f | 0xac64 | 0x0320 | 0x0064 | 0 |

0x0255 0x06b8, 0x0256 0x0030, 0x025c 0x0001, 0x0260 0x3206, 0x0264 0x0141 at every width.

## `fifo-20/`, `fifo-40/`: the FIFO units follow the width

b43 with the width-dependent arm (`CONFIG_B43_DFS`, test build with `scripts/radar-log2.py`, `radar_log=2`: every
FIFO entry logged as `radar <fifo> <w0> <w1> <w2> <w3> lvl <level>`, nothing reported) at 52/20 and 52/40,
pulses from a HackRF One at 5265 and 5262 MHz (gain 35, amp on; the sent pattern beside each file as `.json`).

- time: a 1000 us PRI reads 20000 at 20 MHz and 40000 at 40 MHz (80000 at 80): 50 ns and 25 ns units;
- width: a 20 us pulse reads 25 at 20 MHz and 50 at 40 MHz (100 at 80), a 5 us one 6 and 12: 0.8 us and 0.4 us;
- w2 15:8: at 40 MHz as at 80, 0xc0 or more on every CW and chirped pulse entry, on none of the noise
  bursts' (`noise10`); at 20 MHz fifo 1 reads 0xff on the pulses but 0xe1-0xfb on most noise bursts too, and fifo 0
  0x57-0xaa on pulses of 1-5 us: the byte does not tell them apart there.

`test/radar/check.sh` replays them (`replay -w 20|40`). At both widths ETSI 1 and the 1, 2 and 5 us trains at
1000 us are a radar and the 20 us train is not; the noise bursts are not a radar at 40 MHz and are one (ETSI 2) at
20 MHz.

On the board (`scripts/width_test.sh`): at VHT20, VHT40 and VHT80 the check completes in 60 s with nothing sent,
the arm reads back as `wl`'s, and ETSI 1 in service is detected and the AP leaves the channel.
