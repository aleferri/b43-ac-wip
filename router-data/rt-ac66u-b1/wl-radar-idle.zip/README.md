# RT-AC66U B1: wl 7.14 under DD-WRT r63734 does not run its radar detection (2026-11-04)

Tried in order to trace how the stock driver judges FCC 5 (chirped long pulses) and the 20 MHz noise bursts.
`wl` 7.14.164.18 under DD-WRT r63734, reloaded cold, AP at 52/80, radar and 802.11h on (`WLC_SET_RADAR` 243,
`WLC_SET_SPECT_MANAGMENT` 244), country `US` (the CLI could not set it; it already read 0x5355), no station
(`ddwrt-radar.sh`). FCC 0 from a HackRF at 5270 MHz (gain 35, amp on) as the positive control.

- `wl` never reads its radar FIFOs: the `wl-mmio-trap` capture over the 4 s of the burst (`fcc0-ops.txt`, decoded
  with `reverse-tools/mmio2ops.py`) has no access to PHY 0x0251-0x0254.
- Its DFS state stays idle: `dfs_status` all zeros before and after, `radar_status` all zeros, the AP stays on
  52/80. `dfs_ism_monitor` reads 0; set to 1, a second FCC 0 burst changes none of it.
- The detector is armed as in `radar-widths.zip` (0x0250 0xac64, 0x025b 0x001f, 0x0262 0x0320, 0x0263 0x0064),
  and the FIFOs fill without being drained (0x0251 0x003c, 0x0252 0x0170, `probe.txt`).

So this build cannot say how `wl` matches FCC 5. `radarargs` (its detector parameters, raw 32-bit words, read
through `wlx iovarhex`; this CLI prints only the first word) is kept in `run.log` and `probe.txt`, the same before
and after the bss is up.
