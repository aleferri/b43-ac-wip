#!/bin/bash
# ddwrt-radar.sh <run> <country> <chanspec> <pattern.iq>...: wl 7.14 under DD-WRT r63734 on the RT-AC66U B1 (eth2,
# 5 GHz) as an AP with its radar on, judging known pulses itself. wl reloaded cold, country set, radar and 802.11h on
# (WLC_SET_RADAR 243, WLC_SET_SPECT_MANAGMENT 244), AP up at <chanspec>, then wl's own view read: radarargs,
# radarthrs, dfs_status, radar_status. Each pattern is played at 5270 MHz (radar_tx.sh, gain 35, amp on) with
# wl-mmio-trap recording only while it plays (marks around it), then radar_status, dfs_status and chanspec again.
# The FIFOs are never read here (that would take the pulses from wl). wl goes down at once if its channel leaves
# 52-64 (a move towards the main router's 100-112 must not happen), and at the end. BAR reads only while wl is up.
# Output ~/re/dumps/trap/<run>/.
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@192.168.2.1"
N=$1; C=$2; CS=$3; shift 3; IF=eth2; D=~/re/dumps/trap/$N; mkdir -p $D
T="insmod /tmp/wl_mmio_trap.ko autoarm=0 win_phys=0x20000000 win_phys_len=0x8000 fsr_info_fn7=0x8057028c init_mm_addr=0x80576c28 fifo_recs=2097152 poll_secs=10 stop_on_full=1"
for f in /home/tossu/re/ddwrt-src/trap/4-4-arm/wl_mmio_trap.ko:/tmp/wl_mmio_trap.ko /home/tossu/re/dfs/wlx/wlx:/tmp/wlx; do
	timeout 60 $R "cat > ${f#*:}; chmod +x ${f#*:}" < ${f%%:*}
done
M='M=/proc/wl_mmio_trap; W=/tmp/wlx'
timeout 120 $R "rmmod wl_mmio_trap 2>/dev/null; killall nas wland 2>/dev/null; rmmod wl; insmod /lib/modules/\$(uname -r)/wl.ko; sleep 3; $T; echo trap=\$?" > $D/run.log 2>&1
grep -q "trap=0" $D/run.log || { echo "$N: trap load failed"; cat $D/run.log; exit 1; }
timeout 900 $R 'cat /proc/wl_mmio_trap' > $D/trace.bin &
RP=$!; sleep 2
wlview() { timeout 30 $R "echo '-- radar_status'; /tmp/wlx $IF iovarhex radar_status 256; echo '-- dfs_status'; /tmp/wlx $IF iovarhex dfs_status 128; echo '-- chanspec'; wl -i $IF chanspec"; }
timeout 150 $R "$M; \$W $IF ap 1; wl -i $IF country $C; echo country=\$(wl -i $IF country); \$W $IF ioctl 243 1; \$W $IF ioctl 244 1; echo radar=\$(\$W $IF ioctl 242); wl -i $IF wsec 0; wl -i $IF chanspec $CS; \$W $IF up; echo rc up=\$?; wl -i $IF ssid radar-test; \$W $IF bss up; echo rc bss=\$?; echo '-- radarargs'; /tmp/wlx $IF iovarhex radarargs 128" >> $D/run.log 2>&1
# wl's own availability check: wait until dfs_status leaves it (or 75 s)
for i in $(seq 1 15); do sleep 5; s=$(timeout 10 $R "/tmp/wlx $IF iovarhex dfs_status 16"); echo "$s" >> $D/run.log; done
echo "-- before patterns" >> $D/run.log; wlview >> $D/run.log
for F in "$@"; do
	n=$(basename $F .iq)
	ch=$(timeout 10 $R "wl -i $IF chanspec" | grep -o '^[0-9]*'); case $ch in 52|56|60|64) ;; *) echo "chanspec $ch: stop"; break;; esac
	timeout 10 $R "echo 'mark tx-$n' > /proc/wl_mmio_trap; echo on > /proc/wl_mmio_trap"
	AMP=1 FORCE=1 ~/re/dfs/radar_tx.sh "$F" 5270 35 | grep -i -E 'refused|error|no hackrf'
	sleep 3
	timeout 10 $R "echo off > /proc/wl_mmio_trap; echo 'mark after-$n' > /proc/wl_mmio_trap"
	echo "-- after $n" >> $D/run.log; wlview >> $D/run.log; cp $F.json $D/$n.json
	ch=$(timeout 10 $R "wl -i $IF chanspec" | grep -o '^[0-9]*')
	echo "$n: chanspec now $ch"
	case $ch in 52|56|60|64) ;; *) timeout 10 $R "wl -i $IF down"; echo "$n: wl moved to $ch, taken down"; break;; esac
done
timeout 30 $R "dmesg | tail -40; echo 'mark done' > /proc/wl_mmio_trap; echo status > /proc/wl_mmio_trap; wl -i $IF down" > $D/dmesg.txt 2>&1
sleep 3; timeout 20 $R 'for p in /proc/[0-9]*; do ls -l $p/fd 2>/dev/null | grep -q wl_mmio_trap && kill ${p#/proc/}; done'; wait $RP 2>/dev/null
echo "$N: $(ls -l $D/trace.bin | awk '{print $5}') bytes"
