# RT-AC66U B1: long pulses and FCC 5/6 in the radar FIFOs (2026-11-04)

b43 with `CONFIG_B43_DFS`, 5 GHz AP on ch 52/80, country US (FCC), pulses from a HackRF One at 5270 MHz (gain 35, amp
on) in service. `*.json` beside each log is every pulse sent (`radar_gen.py`).

## `fifo/`: every FIFO entry

A test build that logs each entry (`radar_log=2`: `b43-radar <fifo> <w0> <w1> <w2> <w3> lvl <level>`, nothing
reported), run by `fifo_log_run.sh`. Decoded as in `b43/radar_ac.h` (80 MHz units):

| pattern | entries a pulse | widths read |
|---|---|---|
| CW 50 us, PRI 1000 us | 2 | 27.0, 21.2 us |
| CW 60 us | 3 | 27.0, 26.8, 2.6 us |
| CW 80 us | 3 | 27.0, 26.8, 22.4 us, starting 0, 28.9, 57.6 us |
| CW 100 us | 4 | 27.0, 26.8, 26.8, 13.8 us |
| 80 us chirped by 10 MHz | 1 | 28.8 us |
| FCC 5: 10 bursts over 12 s, 63-95 us, chirped by 13.5 MHz | 1 | 11.6 us (63 us), 17.8 us (69 us), ... |
| FCC 6: 13 hops in the channel, 9 x 1 us at 333 us | 1 | 2.0 us (117 of 119) |

All on fifo 1, `w2 >> 8` 0xff. A CW long pulse comes in parts 28.8 us apart, 27.0 us each and the rest in the last;
a chirped one as one entry much shorter than the pulse, so a width does not tell FCC 5's pulses from short ones. In
the FCC 5 run fifo 0 also holds runs of 27 us parts at times that are none of the pattern's (unexplained; that
run only).

`test/radar/replay` on these logs (`b43-radar poll` as `poll`, `b43-radar <fifo> ...` as `radar <fifo> ...`): FCC 6
matches FCC 6 with the FCC types; the others match nothing.

## `inservice/`: the detector in service

The release build (`region_test.sh`, module reloaded for every run): FCC 6 under US is `radar: FCC 6 pulses` and the
AP leaves ch 52; under FI `radar: ETSI 1 pulses`; FCC 5 under US is not detected.
