#!/usr/bin/env python3
"""radar_gen.py: radar test bursts as HackRF IQ (interleaved int8, complex baseband).

  radar_gen.py OUT.iq --type etsi1|...|etsi6|fcc0|...|fcc6|fcc1|fcc2|fcc3|fcc4|fcc5
  radar_gen.py OUT.iq --pw 2 --pri 1000 --n 18 [--chirp 0] [--bursts 1] [--gap 0.2]

Pulses are CW (or a linear chirp of --chirp MHz across the pulse) at the tuned centre frequency,
amplitude --amp (0..1 of int8 full scale), with --lead seconds of silence before and after. The
pattern parameters follow FCC KDB 905462 D02 (types 0-6) and ETSI EN 301 893 v2.2.1 Table D.4
(types 1-6); one value per range is drawn with --seed so a run can be repeated. Writes OUT.iq and
OUT.json (every pulse's start time, width, chirp), the reference for decoding the b43 radar FIFO words.
"""
import argparse, json, math, random, sys
import numpy as np

FS = 20e6

def pattern(kind, rnd):
    """-> (list of bursts, each a list of (t_us, pw_us, chirp_mhz)), description"""
    def train(pw, pri, n, chirp=0.0, t0=0.0):
        return [(t0 + i * pri, pw, chirp) for i in range(n)]
    if kind == 'fcc0':
        return [train(1, 1428, 18)], 'FCC type 0: 1 us, PRI 1428 us, 18 pulses'
    if kind == 'fcc1':
        pri = rnd.choice(range(518, 3067))
        n = math.ceil((1 / 360) * (19e6 / pri))
        return [train(1, pri, n)], f'FCC type 1: 1 us, PRI {pri} us, {n} pulses'
    if kind == 'fcc2':
        pw, pri, n = rnd.uniform(1, 5), rnd.uniform(150, 230), rnd.randint(23, 29)
        return [train(pw, pri, n)], f'FCC type 2: {pw:.1f} us, PRI {pri:.0f} us, {n} pulses'
    if kind == 'fcc3':
        pw, pri, n = rnd.uniform(6, 10), rnd.uniform(200, 500), rnd.randint(16, 18)
        return [train(pw, pri, n)], f'FCC type 3: {pw:.1f} us, PRI {pri:.0f} us, {n} pulses'
    if kind == 'fcc4':
        pw, pri, n = rnd.uniform(11, 20), rnd.uniform(200, 500), rnd.randint(12, 16)
        return [train(pw, pri, n)], f'FCC type 4: {pw:.1f} us, PRI {pri:.0f} us, {n} pulses'
    if kind == 'fcc5':
        # long pulse (Table 6): 8-20 bursts over 12 s, one in each equal part, 1-3 pulses of one width 50-100 us
        # a burst, 1000-2000 us apart; the chirp, 5-20 MHz, the same for the whole waveform
        nb = rnd.randint(8, 20); chirp = rnd.uniform(5, 20); bursts = []; part = 12e6 / nb
        for b in range(nb):
            t = b * part + rnd.uniform(0, part - 3 * 2100)
            k, pw = rnd.randint(1, 3), rnd.uniform(50, 100)
            bursts.append([(t + j * rnd.uniform(1000, 2000), pw, chirp) for j in range(k)])
        return [[p for b in bursts for p in b]], f'FCC type 5: {nb} bursts over 12 s, chirp {chirp:.1f} MHz'
    if kind == 'fcc6':
        # frequency hopping (Table 7): 1 us at 333 us, 9 pulses a hop, a hop every 3 ms over 475 MHz for 300 ms;
        # only the hops that fall in an 80 MHz channel are sent
        hops = [h for h in range(100) if rnd.random() < 80 / 475]
        return [[(h * 3000 + i * 333.3, 1, 0) for h in hops for i in range(9)]], \
            f'FCC type 6: {len(hops)} of 100 hops in the channel, 9 pulses each'
    if kind in ('etsi1', 'etsi2', 'etsi3', 'etsi4'):
        pw_rng, prf_rng, n, chirp = {
            'etsi1': ((0.5, 5), (200, 1000), 10, 0),
            'etsi2': ((0.5, 15), (200, 1600), 15, 0),
            'etsi3': ((0.5, 15), (2300, 4000), 25, 0),
            'etsi4': ((20, 30), (2000, 4000), 20, 2.5),
        }[kind]
        pw, prf = rnd.uniform(*pw_rng), rnd.uniform(*prf_rng)
        return [train(pw, 1e6 / prf, n, chirp)], f'ETSI {kind[4:]}: {pw:.1f} us, PRF {prf:.0f} Hz, {n} pulses'
    if kind in ('etsi5', 'etsi6'):
        # staggered PRF: 2 or 3 PRFs in turn, at least 20 (5) / 80 (6) pps apart, 10 / 15 pulses each
        (flo, fhi), gap, per = {'etsi5': ((300, 400), 20, 10), 'etsi6': ((400, 1200), 80, 15)}[kind]
        pw, nprf = rnd.uniform(0.5, 2), rnd.choice((2, 3))
        while True:
            prfs = [rnd.uniform(flo, fhi) for _ in range(nprf)]
            if all(abs(a - b) >= gap for i, a in enumerate(prfs) for b in prfs[i + 1:]):
                break
        t, out = 0.0, []
        for i in range(per * nprf):
            out.append((t, pw, 0))
            t += 1e6 / prfs[i % nprf]
        return [out], (f'ETSI {kind[4:]}: {pw:.1f} us, PRFs ' + '/'.join(f'{f:.0f}' for f in prfs)
                       + f' Hz, {per} pulses each')
    sys.exit(f'unknown type {kind}')

def main():
    a = argparse.ArgumentParser()
    a.add_argument('out')
    a.add_argument('--type')
    a.add_argument('--pw', type=float); a.add_argument('--pri', type=float); a.add_argument('--n', type=int)
    a.add_argument('--chirp', type=float, default=0.0, help='MHz swept across each pulse')
    a.add_argument('--bursts', type=int, default=1); a.add_argument('--gap', type=float, default=0.2, help='s between bursts')
    a.add_argument('--amp', type=float, default=0.7); a.add_argument('--lead', type=float, default=0.05)
    a.add_argument('--seed', type=int, default=1)
    a.add_argument('--fo', type=float, default=0.0, help='MHz: tone offset from the tuned frequency (baseband)')
    a.add_argument('--snr', type=float, default=None, help='dB: in-pulse noise mixed into the tone, same total power')
    a.add_argument('--noise', action='store_true', help='pulses of complex Gaussian noise (20 MHz wide), not a tone')
    o = a.parse_args()
    rnd = random.Random(o.seed)
    if o.type:
        trains, desc = pattern(o.type, rnd)
    elif o.pw and o.pri and o.n:
        trains = [[(i * o.pri, o.pw, o.chirp) for i in range(o.n)]]
        desc = (f'custom: {o.pw} us, PRI {o.pri} us, {o.n} pulses, chirp {o.chirp} MHz, offset {o.fo} MHz'
                + (', noise' if o.noise else '') + (f', SNR {o.snr} dB' if o.snr is not None else ''))
    else:
        sys.exit('give --type or --pw/--pri/--n')
    pulses = []
    t_us = o.lead * 1e6
    for b in range(o.bursts):
        for tr in trains:
            for (t, pw, ch) in tr:
                pulses.append((t_us + t, pw, ch))
            t_us += tr[-1][0] + tr[-1][1] + o.gap * 1e6
    total = int((t_us + o.lead * 1e6) * 1e-6 * FS)
    iq = np.zeros(total, dtype=np.complex64)
    for (t, pw, ch) in pulses:
        s, n = int(t * 1e-6 * FS), max(1, int(pw * 1e-6 * FS))
        k = np.arange(n) / FS
        if ch:
            bw = ch * 1e6; T = n / FS
            ph = 2 * np.pi * (-bw / 2 * k + bw / (2 * T) * k * k)
        else:
            ph = np.zeros(n)
        x = np.exp(1j * (ph + 2 * np.pi * o.fo * 1e6 * k))
        if o.noise or o.snr is not None:
            g = np.random.default_rng(o.seed + s)
            nz = (g.standard_normal(n) + 1j * g.standard_normal(n)) / np.sqrt(2)
            if o.noise:
                x = nz
            else:
                r = 10 ** (o.snr / 10)
                x = np.sqrt(r / (1 + r)) * x + np.sqrt(1 / (1 + r)) * nz
            x = x / max(1.0, np.abs(x).max())
        iq[s:s + n] = o.amp * x
    out = np.empty(2 * total, dtype=np.int8)
    out[0::2] = np.clip(np.round(iq.real * 127), -127, 127)
    out[1::2] = np.clip(np.round(iq.imag * 127), -127, 127)
    out.tofile(o.out)
    json.dump({'desc': desc, 'fs': FS, 'bursts': o.bursts, 'seed': o.seed,
               'pulses': [{'t_us': round(t, 3), 'pw_us': round(pw, 3), 'chirp_mhz': ch} for (t, pw, ch) in pulses]},
              open(o.out + '.json', 'w'), indent=1)
    print(f'{desc}; {len(pulses)} pulses, {total / FS:.3f} s, {o.out}')

if __name__ == '__main__':
    main()
