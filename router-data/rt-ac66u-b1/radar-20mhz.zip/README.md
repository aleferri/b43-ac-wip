# RT-AC66U B1: the radar FIFOs at 20 MHz, noise against radar types (2026-11-04)

b43 with `CONFIG_B43_DFS` (test build: `radar_log=2` logs every FIFO entry as
`b43-radar <fifo> <w0> <w1> <w2> <w3> lvl <level>` and reports nothing), 5 GHz AP on ch 52/20, country FI.
Pulses from a HackRF One at 5262 MHz (gain 35, amp on) in service (`HT=VHT20 MHZ=5262 fifo_log_run.sh`); each
`.json` is every pulse sent (`radar_gen.py`). `noise*` are bursts of complex Gaussian noise 20 MHz wide, 2, 10 and
30 us long every 1000 us; `silent-*` 1.2 s of zeros; the others are the ETSI 1-6 and FCC 0, 2-4, 6 test signals and a 20 us pulse chirped by
20 MHz.

Per entry, w3 7:4 and w2 15:8 (`C`: 0xc0 or more):

| run | entries | w3 7:4 = 2 and C |
|---|---|---|
| noise10 (3 runs), noise2, noise30 | 142 | 0 (fifo 1: 7:4 = 0 with C, or 2 without) |
| ETSI 1 / 2 / 4 / 5 / 6 | 36 / 51 / 128 / 72 / 92 | 30 / 43 / 60 / 59 / 87 |
| FCC 0 / 2 / 3 / 4 / 6 | 64 / 91 / 289 / 393 / 147 | 54 / 85 / 47 / 36 / 100 |
| 20 us chirped by 20 MHz | 39 | 20 |
| ETSI 3 (2.4 us at 3741 Hz), `etsi3-2` | 84 | 75 |
| ETSI 3 with the HackRF tuned at 5271 MHz and the pulses 9 MHz below, `etsi3-fo-9` | 34 | 25 |
| nothing sent (`silent-1`, `silent-2`: 1.2 s of zeros, the HackRF transmitting) | 17 / 12 | 0 |
| ETSI 3, first run, `etsi3-flooded` | 713 | 0 |

In `etsi3-flooded` both FIFOs filled up (level 1532, 383 entries each) on a continuous carrier: runs of 23-25 us
entries 28.8 us apart, as a CW long pulse reads, with w2 15:8 low and w3 7:4 of any value, and the burst's pulses
were lost in it. Its source is not known; the HackRF sending zeros gives no such entries. The two repeats read one
entry a pulse and match ETSI 3.

`test/radar/check.sh` replays these logs at `-w 20`.

## `inservice/`: the detector in service at 52/20

The release build with the w3 7:4 rule (`KO=... HT=VHT20 MHZ=5262 region_test.sh FI`, module reloaded for every
run): the noise10 and noise2 bursts are not a radar and the AP stays on ch 52; ETSI 1 and ETSI 4 are
(`radar: ETSI 1 pulses`, `radar: ETSI 4 pulses`) and it leaves.
