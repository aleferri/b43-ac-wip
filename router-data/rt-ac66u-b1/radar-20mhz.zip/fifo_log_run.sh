#!/bin/bash
# fifo_log_run.sh <country> <outdir> <pattern.iq>...: the AC66U's 5 GHz AP on ch52/80 under <country> with
# ~/re/test/b43-fcc56-log.ko and radar_log=2 (every FIFO entry logged, nothing reported); after the CAC each pattern
# is played in service (radar_tx.sh at 5270 MHz, gain 35, amp on) and its "b43-radar" lines go to <outdir>/<name>.txt.
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@${ROUTER:-192.168.2.1}"
C=$1; O=$2; shift 2; mkdir -p "$O"; m="fl-$C-$(date +%s)"
$R "uci set wireless.radio0.country=$C; uci set wireless.radio1.country=$C; uci set wireless.radio1.channel=52; uci set wireless.radio1.htmode=${HT:-VHT80}; uci commit wireless; logger -t dfs $m"
ARGS="radar_log=2" ~/re/test/router-try-module.sh ~/re/test/b43-fcc56-log.ko > /dev/null; $R 'touch /tmp/b43-keep'
for i in $(seq 1 40); do $R "logread | sed -n '/$m/,\$p' | grep -q -E 'DFS-CAC-COMPLETED|DFS-RADAR'" && break; sleep 5; done
$R "iw reg get | grep -m1 country; iw dev | grep -A6 AC66UB1-b43-5g | grep channel"
for F in "$@"; do
	n=$(basename $F .iq); k="flp-$n-$(date +%s)"
	$R "echo $k-start > /dev/kmsg"; sleep 1
	AMP=1 FORCE=1 ~/re/dfs/radar_tx.sh "$F" ${MHZ:-5270} 35 | grep -i -E 'refused|error|no hackrf'
	sleep 2; $R "echo $k-end > /dev/kmsg"
	$R "dmesg | sed -n '/$k-start/,/$k-end/p' | grep -E 'b43-radar|radar:' | sed 's/^\[[ 0-9.]*\] //'" > "$O/$n.txt"
	cp "$F.json" "$O/$n.json"
	echo "$n: $(grep -c '^b43-radar [01] ' "$O/$n.txt") entries, $(grep -c 'b43-radar poll' "$O/$n.txt") polls"
done
$R "logread | sed -n '/$m/,\$p' | grep -E 'DFS-RADAR' | cut -c1-100"
