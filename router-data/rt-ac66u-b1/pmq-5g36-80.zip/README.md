# RT-AC66U B1: the power management queue under wl 7.14, and on b43 (2026-11-04)

## `pmq36-80-*`: wl

`wl` 7.14.164.18 under DD-WRT r63734, reloaded cold, open BSS `bf-test` at 36/80 (`scripts/ddwrt-session2.sh
pmq36-80`); a OnePlus Nord 2 joins, its screen goes off (power save) while the router pings it at 1 s for 45 s plus a
burst every 5 s (RTTs up to 210 ms: buffered), then on again. `-full.bin` is the `wl-mmio-trap` capture
(`fsr_info_fn7=0x8057028c init_mm_addr=0x80576c28`), `-ops.txt` its decode (`reverse-tools/mmio2ops.py`).

- MACCONTROL with the AP up: `0x04160403`, `DISCPMQ` (bit 30) clear.
- The interrupt: bit 6 (`0x40`, `B43_IRQ_PMQ`) of the interrupt status.
- Each entry: RD `0x0140` (bit 3 set; high half `0x0001` or `0x0002`), RD `0x0144` (`0x22541e86`), RD `0x0148`
  (`0x00006629`): the phone's address 86:1e:54:22:29:66; WR16 `0x0140` = `0x0002`; RD `0x0140` again, bit 3 clear
  when empty. 853 entries between the screen going off and the end, nothing else written around them.

## `b43-ab-*`: b43 with and without

b43 main (`DISCPMQ` set) against b43 with the queue run as above (`DISCPMQ` clear as an AP, the drain, PMQ-suppressed
statuses as `TX_FILTERED`, `D11AC_TXC_IPMQ` on `NO_PS_BUFFER`/`CLEAR_PS_FILT`), in turn (`scripts/pmq-ab.sh`): the
Nord 2 with its screen off, 60 pings at 1 s and 30 s of UDP at 2 Mbit/s: no loss either way. With
`scripts/pmq-count.py` (counts printed every 50) under a 40 s TCP downlink (266 Mbit/s) with the screen off twice:
19650 entries in about 70 s and no status suppressed for the queue.
