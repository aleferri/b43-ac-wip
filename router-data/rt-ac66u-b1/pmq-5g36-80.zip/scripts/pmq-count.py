#!/usr/bin/env python3
# TEST ONLY: count PMQ entries drained and TX statuses filtered for the PMQ, printed every 50.
import sys
d = sys.argv[1]
p = d + '/main.c'; s = open(p).read()
old = "\t\tif (ac) {\n\t\t\tb43_read32(dev, B43_MMIO_PMQ_ADDR_LO);"
assert s.count(old) == 1
s = s.replace(old, "\t\tif (ac) {\n\t\t\tstatic unsigned int pmqn;\n\t\t\tif (!(++pmqn % 50))\n\t\t\t\tprintk(KERN_INFO \"b43-pmq entries %u (status 0x%08x)\\n\", pmqn, tmp);\n\t\t\tb43_read32(dev, B43_MMIO_PMQ_ADDR_LO);")
open(p, 'w').write(s)
p = d + '/xmit.c'; s = open(p).read()
old = "\t\tif (status->supp_reason == B43_TXST_SUPP_PMQ)\n\t\t\treport->flags |= IEEE80211_TX_STAT_TX_FILTERED;"
assert s.count(old) == 1
s = s.replace(old, "\t\tif (status->supp_reason == B43_TXST_SUPP_PMQ) {\n\t\t\tstatic unsigned int filt;\n\t\t\tif (!(++filt % 50) || filt < 4)\n\t\t\t\tprintk(KERN_INFO \"b43-pmq filtered %u\\n\", filt);\n\t\t\treport->flags |= IEEE80211_TX_STAT_TX_FILTERED;\n\t\t}")
open(p, 'w').write(s); print('applied')
