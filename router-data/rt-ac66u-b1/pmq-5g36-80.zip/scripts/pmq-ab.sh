#!/bin/bash
# pmq-ab.sh: the power management queue A/B on the RT-AC66U B1 (ch36/80): b43 main (DISCPMQ set) against the pmq branch,
# in turn. Each round: the Nord 2 (USB adb) on AC66UB1-b43-5g, screen off, then from the router 60 pings at 1 s and
# 30 s of UDP at 2 Mbit/s to the phone (iperf3 -R from the phone, started before the screen goes off), then the
# screen on. Reports ping loss/RTT, UDP loss, and the MACCTL DISCPMQ bit. Output ~/re/test/pmq-ab/<n>-<v>.txt
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@192.168.2.1"
PHONE=AAIJOZRW4PMVWGPB; O=~/re/test/pmq-ab; mkdir -p $O
cat ~/re/tools/peek/bcmpeek | $R 'cat > /tmp/bcmpeek; chmod +x /tmp/bcmpeek'
n=0
for v in main pmq main pmq; do
	n=$((n + 1)); ko=~/re/test/b43-main-e574477.ko; [ $v = pmq ] && ko=~/re/test/b43-pmq.ko
	f=$O/$n-$v.txt; echo "== round $n $v" > $f
	ARGS="" ~/re/test/router-try-module.sh $ko >> $f 2>&1; $R 'touch /tmp/b43-keep'
	adb -s $PHONE shell input keyevent KEYCODE_WAKEUP
	for i in $(seq 1 30); do adb -s $PHONE shell cmd wifi status 2>/dev/null | grep -q 'connected to "AC66UB1-b43-5g"' && break
		adb -s $PHONE shell cmd wifi start-scan >/dev/null 2>&1; sleep 5; done
	sleep 5
	IP=$(adb -s $PHONE shell cmd wifi status | grep -o "IP: /[0-9.]*" | cut -d/ -f2); echo "phone $IP" >> $f
	$R "B=/sys/bus/pci/devices/0001:01:00.0/resource0; echo macctl \$(/tmp/bcmpeek \$B mmio 0x120 0x120)" >> $f
	timeout 15 $R "killall iperf3 2>/dev/null; iperf3 -s -D"
	(timeout 60 adb -s $PHONE shell /data/local/tmp/iperf3 -c 192.168.3.1 -u -b 2M -t 30 -R -B $IP 2>&1 | grep -E "receiver|%" | tail -1 > $O/.udp) &
	sleep 2; adb -s $PHONE shell input keyevent KEYCODE_SLEEP
	timeout 90 $R "ping -c 60 -W 2 $IP | tail -2" >> $f 2>&1
	wait; echo "udp: $(cat $O/.udp)" >> $f
	adb -s $PHONE shell input keyevent KEYCODE_WAKEUP
	$R "dmesg | tail -200 | grep -i -E 'b43.*(warn|error|suppress|pmq)' | tail -3; killall iperf3" >> $f 2>&1
	grep -E "^==|macctl|packet loss|round-trip|udp" $f
done
