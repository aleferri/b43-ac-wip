#!/bin/bash
# ddwrt-session2.sh <run>: wl 7.14 captures under DD-WRT r63734 on the RT-AC66U B1 (eth2, 5 GHz) for b43-ac-wip's
# "What is missing" list. Every run: wl reloaded cold, wl-mmio-trap armed, marks around each step; output
# ~/re/dumps/trap/<run>/ (trace.bin, run.log, readback.txt).
#   radar52-20 | radar52-40 | radar52-80   radar on (WLC_SET_RADAR, WLC_SET_SPECT_MANAGMENT) at ch52, no station; PHY
#                                          0x0250-0x0264 and SHM 0x5e/0x66 read back after the bss is up
#   pmq36-80                               open BSS, the Nord 2 joins, then its screen goes off (power save) while the
#                                          router pings it every 300 ms for 40 s; screen on again
#   mbss36-80                              two WPA2 BSSes (bf-test, bf-test2, each with nas), the Nord 2 joins the second
# BAR reads only while wl is up (a read while it is down hangs the SoC).
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@192.168.2.1"
PHONE=AAIJOZRW4PMVWGPB; N=$1; IF=eth2; D=~/re/dumps/trap/$N; mkdir -p $D; PSK=bftest-psk-2026; B=0x20000000
T="insmod /tmp/wl_mmio_trap.ko autoarm=0 win_phys=0x20000000 win_phys_len=0x8000 fsr_info_fn7=0x8057028c init_mm_addr=0x80576c28 fifo_recs=2097152 poll_secs=10 stop_on_full=1"
for f in /home/tossu/re/ddwrt-src/trap/4-4-arm/wl_mmio_trap.ko:/tmp/wl_mmio_trap.ko /home/tossu/re/dfs/wlx/wlx:/tmp/wlx \
	/home/tossu/re/tools/iperf/iperf3-arm-static:/tmp/iperf3 /home/tossu/re/tools/peek/bcmpeek:/tmp/bcmpeek; do
	timeout 60 $R "[ -s ${f#*:} ] || { cat > ${f#*:}; chmod +x ${f#*:}; }" < ${f%%:*}
done
M='M=/proc/wl_mmio_trap; W=/tmp/wlx'
timeout 120 $R "rmmod wl_mmio_trap 2>/dev/null; killall nas wland 2>/dev/null; ifconfig br0:1 down 2>/dev/null; brctl delif br0 eth2 2>/dev/null; rmmod wl; insmod /lib/modules/\$(uname -r)/wl.ko; sleep 3; $T; echo trap=\$?" > $D/run.log 2>&1
grep -q "trap=0" $D/run.log || { echo "$N: trap load failed"; cat $D/run.log; exit 1; }
timeout 900 $R 'cat /proc/wl_mmio_trap' > $D/trace.bin &
RP=$!; sleep 2
readback() { timeout 30 $R "echo '-- phy 0x0250-0x0264'; /tmp/bcmpeek $B phy 0x0250 0x0264; echo '-- shm'; /tmp/bcmpeek $B shm 0x005e 0x0066; echo '-- macctl'; /tmp/bcmpeek $B mmio 0x0120 0x0120" > $D/readback.txt 2>&1; }
case $N in
radar52-*)
	CS=52/${N#radar52-}
	timeout 120 $R "$M; echo 'mark $N' > \$M; echo on > \$M; \$W $IF ap 1; echo 'mark set-radar' > \$M; \$W $IF ioctl 243 1; \$W $IF ioctl 244 1; echo radar=\$(\$W $IF ioctl 242); wl -i $IF wsec 0; wl -i $IF chanspec $CS; echo 'mark up' > \$M; \$W $IF up; echo rc up=\$?; wl -i $IF ssid radar-test; echo 'mark bss-up' > \$M; \$W $IF bss up; echo rc bss=\$?; sleep 8; echo 'mark running' > \$M; wl -i $IF chanspec" >> $D/run.log 2>&1
	readback
	timeout 30 $R "sleep 5; echo 'mark done' > /proc/wl_mmio_trap; echo off > /proc/wl_mmio_trap; echo status > /proc/wl_mmio_trap" >> $D/run.log 2>&1
	;;
pmq36-80)
	timeout 60 $R "$M; echo 'mark $N' > \$M; echo on > \$M; \$W $IF ap 1; wl -i $IF wsec 0; wl -i $IF chanspec 36/80; echo 'mark up' > \$M; \$W $IF up; sleep 3; wl -i $IF ssid bf-test; echo 'mark bss-up' > \$M; \$W $IF bss up; brctl addif br0 $IF; ifconfig $IF up; ifconfig br0:1 192.168.1.250 netmask 255.255.255.0 up" >> $D/run.log 2>&1
	adb -s $PHONE shell "input keyevent KEYCODE_WAKEUP; cmd wifi remove-suggestion bf-test; cmd wifi add-suggestion bf-test open" >/dev/null 2>&1
	for i in $(seq 1 60); do adb -s $PHONE shell cmd wifi start-scan >/dev/null 2>&1; n=$(timeout 10 $R "wl -i $IF assoclist" 2>/dev/null | grep -c assoclist); [ "$n" -gt 0 ] && break; sleep 2; done
	for i in $(seq 1 20); do IP=$(adb -s $PHONE shell cmd wifi status | grep -o "IP: /[0-9.]*" | cut -d/ -f2); [ -n "$IP" ] && break; sleep 2; done
	echo "phone ip $IP" >> $D/run.log; readback
	timeout 10 $R "echo 'mark screen-off' > /proc/wl_mmio_trap"; adb -s $PHONE shell input keyevent KEYCODE_SLEEP
	sleep 5
	timeout 90 $R "(for k in 1 2 3 4 5 6 7 8 9; do sleep 5; ping -c 3 -s 1200 -W 1 $IP >/dev/null 2>&1; done) & ping -c 45 -W 1 $IP | tail -2; wait" >> $D/run.log 2>&1
	timeout 10 $R "echo 'mark screen-on' > /proc/wl_mmio_trap"; adb -s $PHONE shell input keyevent KEYCODE_WAKEUP
	timeout 30 $R "ping -c 10 $IP | tail -1; echo 'mark done' > /proc/wl_mmio_trap; echo off > /proc/wl_mmio_trap; echo status > /proc/wl_mmio_trap; ifconfig br0:1 down" >> $D/run.log 2>&1
	adb -s $PHONE shell "cmd wifi remove-suggestion bf-test" >/dev/null 2>&1
	;;
mbss36-80)
	timeout 90 $R "$M; echo 'mark $N' > \$M; echo on > \$M; \$W $IF ap 1; wl -i $IF mbss 1; echo rc mbss=\$?; wl -i $IF wsec 4; wl -i $IF wpa_auth 0x80; wl -i $IF chanspec 36/80; echo 'mark up' > \$M; \$W $IF up; echo rc up=\$?; sleep 3; wl -i $IF ssid bf-test; echo 'mark bss0-up' > \$M; \$W $IF bss up; brctl addif br0 $IF; ifconfig $IF up; nas -P /tmp/nas.0.pid -H 34954 -l br0 -i $IF -A -m 128 -w 4 -s bf-test -k $PSK -g 3600 >/dev/null 2>&1 & sleep 3; echo 'mark bss1-cfg' > \$M; wl -i $IF ssid -C 1 bf-test2; echo rc ssid1=\$?; \$W $IF bss up 1; echo rc bss1=\$?; wl -i wl1.1 wsec 4 2>/dev/null; wl -i wl1.1 wpa_auth 0x80 2>/dev/null; ifconfig wl1.1 up 2>/dev/null; brctl addif br0 wl1.1 2>/dev/null; echo 'mark bss1-nas' > \$M; nas -P /tmp/nas.1.pid -H 34954 -l br0 -i wl1.1 -A -m 128 -w 4 -s bf-test2 -k $PSK -g 3600 >/dev/null 2>&1 & sleep 3; echo nas=\$(pidof nas); ifconfig | grep -o '^wl[0-9.]*'; wl -i wl1.1 bss; wl -i wl1.1 ssid" >> $D/run.log 2>&1
	adb -s $PHONE shell "input keyevent KEYCODE_WAKEUP; cmd wifi remove-suggestion bf-test2; cmd wifi add-suggestion bf-test2 wpa2 $PSK" >/dev/null 2>&1
	for i in $(seq 1 60); do adb -s $PHONE shell cmd wifi start-scan >/dev/null 2>&1; n=$(timeout 10 $R "wl -i wl1.1 assoclist" 2>/dev/null | grep -c assoclist); [ "$n" -gt 0 ] && break; sleep 2; done
	timeout 10 $R "echo 'mark assoc' > /proc/wl_mmio_trap; wl -i wl1.1 assoclist | sed 's/..:..:..\$/xx:xx:xx/'" >> $D/run.log 2>&1
	sleep 10; readback
	timeout 30 $R "echo 'mark done' > /proc/wl_mmio_trap; echo off > /proc/wl_mmio_trap; echo status > /proc/wl_mmio_trap; killall nas" >> $D/run.log 2>&1
	adb -s $PHONE shell "cmd wifi remove-suggestion bf-test2" >/dev/null 2>&1
	;;
*) echo "unknown run $N"; kill $RP; exit 1;;
esac
sleep 5; timeout 20 $R 'for p in /proc/[0-9]*; do ls -l $p/fd 2>/dev/null | grep -q wl_mmio_trap && kill ${p#/proc/}; done'; wait $RP 2>/dev/null
timeout 30 $R 'dmesg | tail -30' > $D/dmesg.txt
echo "$N: $(ls -l $D/trace.bin | awk '{print $5}') bytes; $(grep -o 'emulated=[0-9]* .*' $D/run.log | tail -1)"
