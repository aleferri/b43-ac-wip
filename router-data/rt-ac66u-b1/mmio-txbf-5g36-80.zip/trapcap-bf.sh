#!/bin/bash
# trapcap-bf.sh <name>: cold wl-mmio-trap capture of eth2 (5g36/80) with txbf 1, then a VHT beamformee (the phone)
# (DD=1: TX descriptors and headers, 168 bytes x 256, during traffic) associating to the open SSID bf-test (phone: cmd wifi add-suggestion bf-test open) and pulling iperf3 downlink. Output ~/re/dumps/trap/<name>/
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@192.168.2.1"
. ~/re/test/phone-env.sh
N=$1; IF=eth2; D=~/re/dumps/trap/$N; mkdir -p $D
T="insmod /tmp/wl_mmio_trap.ko autoarm=0 win_phys=0x20000000 win_phys_len=0x8000 fsr_info_fn7=0x805702cc init_mm_addr=0x80576c68 fifo_recs=2097152 poll_secs=10 stop_on_full=1"
cat ~/re/tools/iperf/iperf3-arm-static | timeout 30 $R 'cat > /tmp/iperf3; chmod +x /tmp/iperf3'
timeout 120 $R "rmmod wl_mmio_trap 2>/dev/null; killall nas wland 2>/dev/null; brctl delif br0 eth1 2>/dev/null; brctl delif br0 eth2 2>/dev/null; rmmod wl; insmod /lib/modules/\$(uname -r)/wl.ko; sleep 3; $T; echo trap=\$?; dmesg | grep wl_mmio_trap | tail -1" > $D/run.log 2>&1
grep -q "trap=0" $D/run.log || { echo "$N: trap load failed"; cat $D/run.log; exit 1; }
timeout 400 $R 'cat /proc/wl_mmio_trap' > $D/trace.bin &
RP=$!; sleep 2
timeout 60 $R "W=/tmp/wlx; M=/proc/wl_mmio_trap; date; echo 'mark $N' > \$M; echo on > \$M; \$W $IF ap 1; for c in 'txbf 1' 'txbf_bfr_cap 1' 'txbf_bfe_cap 0' 'vhtmode 1' 'wsec 0'; do echo rc \$c=\$(wl -i $IF \$c >/dev/null 2>&1; echo \$?); done; echo 'mark chanspec' > \$M; wl -i $IF chanspec 36/80; echo rc chanspec=\$?; echo 'mark up' > \$M; \$W $IF up; echo rc up=\$?; sleep 5; echo 'mark ssid' > \$M; wl -i $IF ssid bf-test; echo 'mark bss-up' > \$M; \$W $IF bss up; echo rc bss=\$?; brctl addif br0 $IF; ifconfig $IF up; echo 'mark assoc-wait' > \$M; wl -i $IF chanspec; wl -i $IF txbf" >> $D/run.log 2>&1
adb -s $PHONE shell "cmd wifi remove-suggestion bf-test; cmd wifi add-suggestion bf-test open" >/dev/null 2>&1
for i in $(seq 1 60); do adb -s $PHONE shell cmd wifi start-scan >/dev/null 2>&1; n=$(timeout 10 $R "wl -i $IF assoclist" 2>/dev/null | grep -c assoclist); [ "$n" -gt 0 ] && break; sleep 2; done
timeout 10 $R "echo 'mark assoc' > /proc/wl_mmio_trap; wl -i $IF assoclist | sed 's/..:..:..\$/xx:xx:xx/'; /tmp/iperf3 -s -D" >> $D/run.log 2>&1
for i in $(seq 1 20); do IP=$(adb -s $PHONE shell cmd wifi status | grep -o "IP: /[0-9.]*" | cut -d/ -f2); case "$IP" in 192.168.2.*) break;; esac; sleep 2; done
echo "phone ip ok=$([ -n "$IP" ] && echo 1)" >> $D/run.log
timeout 10 $R "[ -n \"$DD\" ] && { echo 168 > /sys/module/wl_mmio_trap/parameters/dd_len; echo 256 > /sys/module/wl_mmio_trap/parameters/dd_budget; }; echo 'mark traffic' > /proc/wl_mmio_trap"
timeout 30 adb -s $PHONE shell /data/local/tmp/iperf3 -c 192.168.2.1 -t 8 -R -B $IP 2>&1 | tail -3 >> $D/run.log
timeout 30 $R "M=/proc/wl_mmio_trap; echo 'mark traffic-end' > \$M; echo off > \$M; echo 'mark done' > \$M; wl -i $IF txbf; wl -i $IF sta_info \$(wl -i $IF assoclist | awk '{print \$2}' | head -1) 2>/dev/null | grep -i -E 'bf|beamform|vht caps|rate of last' ; sleep 2; echo status > \$M; dmesg | grep wl_mmio_trap | tail -2; killall iperf3 nas" >> $D/run.log 2>&1
sleep 5; timeout 20 $R 'for p in /proc/[0-9]*; do ls -l $p/fd 2>/dev/null | grep -q wl_mmio_trap && kill ${p#/proc/}; done'; wait $RP 2>/dev/null
timeout 30 $R 'dmesg' > $D/dmesg.txt
echo "$N: $(ls -l $D/trace.bin | awk '{print $5}') bytes; $(grep -o 'emulated=[0-9]* .*' $D/run.log | tail -1)"
