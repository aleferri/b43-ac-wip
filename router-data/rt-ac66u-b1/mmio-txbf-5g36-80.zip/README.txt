RT-AC66U B1 (BCM4708, DD-WRT r66396, kernel 4.4.302-rt232-st79, built 2026-10-24), wl 7.14.164.18 (r692288).
eth2 = 5 GHz BCM4360 rev 3 (0002:01:00.0, BAR0 0x20000000). wl-mmio-trap 4-4-arm at 474f184, loaded as:
  insmod wl_mmio_trap.ko autoarm=0 win_phys=0x20000000 win_phys_len=0x8000 fsr_info_fn7=0x805702cc init_mm_addr=0x80576c68 fifo_recs=2097152 poll_secs=10 stop_on_full=1
Two runs, the same but for txbf; TX descriptors and headers recorded during the traffic (DD=1).
Sequence (trapcap-bf.sh; trapcap-bf0.sh is the same with txbf 0 txbf_bfr_cap 0): nas/wland killed, eth1/eth2 out of br0,
rmmod wl; insmod wl (attach NOT traced), trap loaded, then under the trap:
  mark <run> | on | wl ap 1 | wl txbf 1 | wl txbf_bfr_cap 1 | wl txbf_bfe_cap 0 | wl vhtmode 1 | wl wsec 0 | mark chanspec | wl chanspec 36/80 |
  mark up | wl up | sleep 5 | mark ssid | wl ssid bf-test | mark bss-up | wl bss up | brctl addif br0 eth2; ifconfig eth2 up |
  mark assoc-wait | (a OnePlus Nord 2, VHT SU beamformee, 2 streams, joins the open BSS bf-test) | mark assoc |
  (DHCP from DD-WRT's dnsmasq) | dd_len=168 dd_budget=256 | mark traffic | iperf3 -R 8 s to the phone | mark traffic-end | off | mark done

run              txbf  trap counters                                                                       downlink
bf-dd-5g36-80    1     emulated=433066 dd=256 foreign=2655 not-ls=0 mismatch=0 cond=0 drops=0   61.9 Mbit/s
nobf-dd-5g36-80  0     emulated=487438 dd=256 foreign=2508 not-ls=0 mismatch=0 cond=0 drops=0   73.4 Mbit/s
(throughput under the trap, every register access an exception: not a measure of the radio.)

Files per run: <run>-full.bin (raw stream), <run>-ops.txt (reverse-tools/mmio2ops.py, default format), <run>-run.log,
<run>-decode.txt (decode-wl-mmio.py, with the TX descriptors and headers). The phone's MAC is a random one and is
masked in the run logs only; the router's and the phone's addresses are as captured in the traces.
In <run>-decode.txt the TX headers proper are the ones on chanspec 0xe02a: frames to the phone and one IPv4 multicast.
The other "txh" blocks are the decoder reading later buffers of a frame (its payload) as a header: their fields and
"addresses" are payload bytes.

What differs with txbf 1 (all write addresses compared, every class; two earlier runs without the descriptor
recording, not included, showed the same):
- only shared memory. wl reads SHM 0x00b0 = 0x0406 in both runs (the beamforming block, word address: byte 0x080c);
  with txbf 1, between 'assoc-wait' and 'assoc' (the beamformee joining), it writes slot 0 of it, once:
    0x0814 = 0x0015   (block + 0x08)
    0x0816 = 0x0003   (+ 0x0a)
    0x0818 = 0x400d   (+ 0x0c)
    0x081e/0x0820/0x0822 = 0xd904 0x19f5 0xecb8   (+ 0x12..0x16: the AP's own address, 04:d9:f5:19:b8:ec)
  +0x0e and +0x10 are not written at association; the 24-byte bulk writes at 0x0808 (at init and after 'ssid', both runs)
  cover them.
- in the TX headers, every VHT data frame to the phone (70 with txbf 1, 81 with txbf 0), on all four rate
  blocks:
    phy_ctl word 0   0x81cf with txbf 1, 0x81c7 with txbf 0: bit 3 (0x0008) set for the beamformee
    last word (bfm)  0x0009 with txbf 1, 0x0000 with txbf 0
  and the same in both: cores 0x7, rts_cts word 0x0905/0x0925 (bits 15:12 clear), VHT-SIG-A f6 07 80 95 02 00
  (MCS9, NSTS 2, SGI, LDPC; the SIG-A2 Beamformed bit clear in what the host writes).
