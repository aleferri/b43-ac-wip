RT-AC66U B1: transmit beamforming under wl 7.14 at 20/40/80 MHz, WPA2, two beamformees (2026-11-03)

Board: ASUS RT-AC66U B1 (BCM4708, 5 GHz BCM4360 rev 3, radio 2069 rev 4, femctrl 3, three TX chains).
Driver: DD-WRT r63734 (kernel 4.4.302-rt232-st71, Feb 17 2026), wl.ko 7.14.164.18 (r692288), eth2 = 5 GHz.
Captures: wl-mmio-trap (4-4-arm build, this repo) on BAR0 of eth2 (win_phys 0x20000000), with this kernel's
fsr_info_fn7=0x8057028c and init_mm_addr=0x80576c28 (fsr_info rows 1/4/5/7 checked through /dev/mem; the
addresses in wl-mmio-trap/4-4-arm/README.md belong to another DD-WRT build). TX descriptors and headers of
the traffic recorded (dd_len 168, dd_budget 256). Decoded with reverse-tools/mmio2ops.py (*-ops.txt);
wl-mmio-trap/decode-wl-mmio.py decodes the *-full.bin with the TX headers.

Every run: wl reloaded cold, `ap 1`, txbf 1, txbf_bfr_cap 1, txbf_bfe_cap 0, vhtmode 1, chanspec, up, SSID
bf-test, bss up (trapcap-bf2.sh); the beamformee a OnePlus Nord 2 (MediaTek, two streams), 10 s of iperf3
downlink from the router.

  bf-dd-5g36-20        36/20, open
  bf-dd-5g36-40        36/40, open
  bf-dd-5g36-80-wpa2   36/80, WPA2-PSK (wsec 4, wpa_auth 0x80, nas as authenticator)
  bf-dd-5g36-80-2bfe   36/80, open, a second beamformee: the PC's rtl8821ae (one stream), pinged during the
                       phone's downlink
  bf-dd-5g36-80-wpa2-2bfe
                       36/80, WPA2-PSK, both beamformees (the phone first, slot 0; the rtl8821ae, slot 1)

readback-*.txt: SHM 0x0800-0x085f (the txbf block, slot 0 at 0x080c, slot 1 at 0x082c), 0x0660-0x066f and
0x00b0 read back with bcmpeek after the stations joined, at 36/20, 36/40, 36/80, and 36/80 with both
(bfread-ddwrt.sh).

What they show (words of a slot counted from 0, as in b43's b43_txbf_write_slot()):

- word 6 (+0x0c) at the join: 0x000d at 20 MHz, 0x200d at 40, 0x400d at 80; 0x400d in slot 1 too (no slot
  term);
- word 5 (+0x0a): 0x0003 for the Nord 2 (two streams), 0x0002 for the rtl8821ae (one stream);
- word 4 (+0x08) 0x0015 and words 9-11 (+0x12..+0x16) the AP's address, for both stations;
- words 7 and 8 (+0x0e, +0x10) are never written at a join: they read 0x1471 and 0x8492 at 20, 40 and 80
  MHz and in both slots, the values a slot has before any station (slot 1 before the PC joined: 0x001d
  0x0003 0x40e5 0x1471 0x8492 at +0x08..+0x10);
- the key's address match row: with WPA2, right after the station's AMT entry, wl reads its row in the table
  at SHM 0x0668 (0x0000) and writes 0x1000 | slot << 13: 0x0668 0x1000 for the phone (row 0, slot 0), 0x066a
  0x3000 for the rtl8821ae (row 1, slot 1); nothing on an open BSS, where wl beamforms without a row;
- with txbf the beacon announces SU beamformer and two sounding dimensions (VHT capabilities 0x0f824832;
  0x03800032 without, mmio-txbf-5g36-80.zip);
- the RTS/CTS word of the TX header's rate blocks: 0x0905 for the Nord 2 (slot 0), 0x1905 for the
  rtl8821ae (slot 1): bits 15:12 are the slot. Both rate blocks carry bfm 0x0009.
