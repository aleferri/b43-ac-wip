#!/bin/bash
# trapcap-bf2.sh <name> <chanspec> <open|wpa2> [pc]: cold wl-mmio-trap capture of eth2 (5 GHz) under DD-WRT wl with
# txbf 1 on <chanspec> (36/20, 36/40, 36/80 only), the Nord 2 (USB adb) joining the SSID bf-test (open, or WPA2-PSK
# through nas), TX descriptors recorded (dd_len 168) during traffic; with "pc", the PC's rtl8821ae joins too as a
# second beamformee (under 140 s, wifi-guard) and pulls pings. Output ~/re/dumps/trap/<name>/.
# For aleferri/b43-ac-wip#19: slot words at 20/40 MHz and per stream count, the key AMT mark, the RTS/CTS slot bits.
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@192.168.2.1"
. ~/re/test/phone-env.sh
N=$1; CS=$2; SEC=$3; PC=$4; IF=eth2; D=~/re/dumps/trap/$N; mkdir -p $D; PSK=bftest-psk-2026
case $CS in 36/20|36/40|36/80) ;; *) echo "chanspec $CS refused: ch36 only"; exit 1;; esac
T="insmod /tmp/wl_mmio_trap.ko autoarm=0 win_phys=0x20000000 win_phys_len=0x8000 fsr_info_fn7=0x8057028c init_mm_addr=0x80576c28 fifo_recs=2097152 poll_secs=10 stop_on_full=1"
WS="wsec 0"; [ "$SEC" = wpa2 ] && WS="wsec 4"
# this DD-WRT build (r63734 kernel, Feb 17 2026): fsr_info at 0x8057021c (rows 1/4/5/7 checked), init_mm 0x80576c28
for f in /home/tossu/re/ddwrt-src/trap/4-4-arm/wl_mmio_trap.ko:/tmp/wl_mmio_trap.ko /home/tossu/re/dfs/wlx/wlx:/tmp/wlx \
	/home/tossu/re/tools/iperf/iperf3-arm-static:/tmp/iperf3; do
	timeout 60 $R "[ -s ${f#*:} ] || { cat > ${f#*:}; chmod +x ${f#*:}; }" < ${f%%:*}
done
timeout 120 $R "rmmod wl_mmio_trap 2>/dev/null; killall nas wland 2>/dev/null; brctl delif br0 eth1 2>/dev/null; brctl delif br0 eth2 2>/dev/null; rmmod wl; insmod /lib/modules/\$(uname -r)/wl.ko; sleep 3; $T; echo trap=\$?; dmesg | grep wl_mmio_trap | tail -1" > $D/run.log 2>&1
grep -q "trap=0" $D/run.log || { echo "$N: trap load failed"; cat $D/run.log; exit 1; }
timeout 600 $R 'cat /proc/wl_mmio_trap' > $D/trace.bin &
RP=$!; sleep 2
timeout 60 $R "W=/tmp/wlx; M=/proc/wl_mmio_trap; date; echo 'mark $N' > \$M; echo on > \$M; \$W $IF ap 1; for c in 'txbf 1' 'txbf_bfr_cap 1' 'txbf_bfe_cap 0' 'vhtmode 1' '$WS'; do echo rc \$c=\$(wl -i $IF \$c >/dev/null 2>&1; echo \$?); done; [ '$SEC' = wpa2 ] && { echo rc wpa_auth=\$(wl -i $IF wpa_auth 0x80 >/dev/null 2>&1; echo \$?); }; echo 'mark chanspec' > \$M; wl -i $IF chanspec $CS; echo rc chanspec=\$?; echo 'mark up' > \$M; \$W $IF up; echo rc up=\$?; sleep 5; echo 'mark ssid' > \$M; wl -i $IF ssid bf-test; echo 'mark bss-up' > \$M; \$W $IF bss up; echo rc bss=\$?; brctl addif br0 $IF; ifconfig $IF up; [ '$SEC' = wpa2 ] && { nas -P /tmp/nas.bf.pid -H 34954 -l br0 -i $IF -A -m 128 -w 4 -s bf-test -k $PSK -g 3600 >/dev/null 2>&1 & sleep 2; echo nas=\$(pidof nas); }; echo 'mark assoc-wait' > \$M; wl -i $IF chanspec; wl -i $IF txbf" >> $D/run.log 2>&1
if [ "$SEC" = wpa2 ]; then S="cmd wifi add-suggestion bf-test wpa2 $PSK"; else S="cmd wifi add-suggestion bf-test open"; fi
adb -s $PHONE shell "cmd wifi remove-suggestion bf-test; $S" >/dev/null 2>&1
for i in $(seq 1 60); do adb -s $PHONE shell cmd wifi start-scan >/dev/null 2>&1; n=$(timeout 10 $R "wl -i $IF assoclist" 2>/dev/null | grep -c assoclist); [ "$n" -gt 0 ] && break; sleep 2; done
timeout 10 $R "echo 'mark assoc' > /proc/wl_mmio_trap; wl -i $IF assoclist | sed 's/..:..:..\$/xx:xx:xx/'; /tmp/iperf3 -s -D" >> $D/run.log 2>&1
# the phone keeps the address it had on the main LAN (192.168.1.x/24) on bf-test and does not ask DD-WRT's dnsmasq;
# DD-WRT's LAN is cut off from the main LAN (WAN disabled), so br0 gets an alias in that subnet as the iperf target
for i in $(seq 1 20); do IP=$(adb -s $PHONE shell cmd wifi status | grep -o "IP: /[0-9.]*" | cut -d/ -f2); [ -n "$IP" ] && break; sleep 2; done
SRV=192.168.2.1; case "$IP" in 192.168.1.*) SRV=192.168.1.250; timeout 10 $R "ifconfig br0:1 $SRV netmask 255.255.255.0 up";; esac
echo "phone ip $IP, iperf target $SRV; ping $(adb -s $PHONE shell ping -c 2 -W 2 $SRV | grep -c ' bytes from ')/2" >> $D/run.log
if [ "$PC" = pc ]; then
	nmcli con delete bftest >/dev/null 2>&1
	SECA=""; [ "$SEC" = wpa2 ] && SECA="wifi-sec.key-mgmt wpa-psk wifi-sec.psk $PSK"
	nmcli con add type wifi ifname wlp5s0 con-name bftest autoconnect no ssid bf-test ipv4.method manual ipv4.addresses 192.168.2.31/24 ipv4.never-default yes ipv6.method disabled $SECA >/dev/null
	timeout 45 nmcli --wait 40 con up bftest >/dev/null 2>&1; echo "pc assoc rc=$?" >> $D/run.log
	# the cable is on 192.168.2.0/24 too: pin the PC's Wi-Fi address to its Wi-Fi MAC on the router
	timeout 10 $R "arp -s 192.168.2.31 $(cat /sys/class/net/wlp5s0/address)" >> $D/run.log 2>&1
	timeout 10 $R "echo 'mark assoc-pc' > /proc/wl_mmio_trap; wl -i $IF assoclist | sed 's/..:..:..\$/xx:xx:xx/'" >> $D/run.log 2>&1
fi
timeout 10 $R "echo 168 > /sys/module/wl_mmio_trap/parameters/dd_len; echo 256 > /sys/module/wl_mmio_trap/parameters/dd_budget; echo 'mark traffic' > /proc/wl_mmio_trap"
[ "$PC" = pc ] && (timeout 25 ping -q -I wlp5s0 -s 1400 -i 0.01 -c 2000 192.168.2.1 >> $D/run.log 2>&1 &)
timeout 30 adb -s $PHONE shell /data/local/tmp/iperf3 -c $SRV -t 10 -R -B $IP 2>&1 | tail -3 >> $D/run.log
timeout 30 $R "M=/proc/wl_mmio_trap; echo 'mark traffic-end' > \$M; echo off > \$M; echo 'mark done' > \$M; wl -i $IF txbf; for s in \$(wl -i $IF assoclist | awk '{print \$2}'); do wl -i $IF sta_info \$s 2>/dev/null | grep -i -E 'bf|beamform|vht caps|rate of last|state'; done; sleep 2; echo status > \$M; dmesg | grep wl_mmio_trap | tail -2; killall iperf3 nas; ifconfig br0:1 down 2>/dev/null" >> $D/run.log 2>&1
if [ "$PC" = pc ]; then nmcli con down bftest >/dev/null 2>&1; nmcli con delete bftest >/dev/null 2>&1; nmcli --wait 40 con up "Auto PonyWorld 5G" >/dev/null 2>&1; nmcli --wait 20 con up ddwrt-static >/dev/null 2>&1; fi
adb -s $PHONE shell "cmd wifi remove-suggestion bf-test" >/dev/null 2>&1
sleep 5; timeout 20 $R 'for p in /proc/[0-9]*; do ls -l $p/fd 2>/dev/null | grep -q wl_mmio_trap && kill ${p#/proc/}; done'; wait $RP 2>/dev/null
timeout 30 $R 'dmesg' > $D/dmesg.txt
echo "$N: $(ls -l $D/trace.bin | awk '{print $5}') bytes; $(grep -o 'emulated=[0-9]* .*' $D/run.log | tail -1)"
