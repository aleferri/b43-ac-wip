#!/bin/bash
# bfread-ddwrt.sh <chanspec> [pc]: under DD-WRT wl, bring up eth2 with txbf 1 on <chanspec> (ch36 only), let the Nord 2
# (and with "pc" the rtl8821ae) join the open SSID bf-test, then read back the txbf block (SHM 0x0800-0x085f: slot 0
# at 0x080c, slot 1 at 0x082c) and 0x0660-0x066f with bcmpeek. BARs are read only once stations are associated
# (a read while wl is down hangs the SoC). Output ~/re/dumps/wl/bfread/<chanspec>[-pc].txt
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@192.168.2.1"
. ~/re/test/phone-env.sh 2>/dev/null
CS=$1; PC=$2; IF=eth2; O=~/re/dumps/wl/bfread; mkdir -p $O; F=$O/${CS/\//-}${PC:+-pc}.txt
case $CS in 36/20|36/40|36/80) ;; *) echo "chanspec $CS refused: ch36 only"; exit 1;; esac
timeout 60 $R "[ -s /tmp/bcmpeek ] || { cat > /tmp/bcmpeek; chmod +x /tmp/bcmpeek; }" < ~/re/tools/peek/bcmpeek
timeout 120 $R "killall nas wland 2>/dev/null; brctl delif br0 eth2 2>/dev/null; rmmod wl; insmod /lib/modules/\$(uname -r)/wl.ko; sleep 3; W=/tmp/wlx; \$W $IF ap 1; for c in 'txbf 1' 'txbf_bfr_cap 1' 'txbf_bfe_cap 0' 'vhtmode 1' 'wsec 0'; do wl -i $IF \$c; done; wl -i $IF chanspec $CS; \$W $IF up; sleep 5; wl -i $IF ssid bf-test; \$W $IF bss up; brctl addif br0 $IF; ifconfig $IF up; wl -i $IF chanspec" > $F 2>&1
adb -s $PHONE shell "cmd wifi remove-suggestion bf-test; cmd wifi add-suggestion bf-test open" >/dev/null 2>&1
for i in $(seq 1 60); do adb -s $PHONE shell cmd wifi start-scan >/dev/null 2>&1; n=$(timeout 10 $R "wl -i $IF assoclist" 2>/dev/null | grep -c assoclist); [ "$n" -gt 0 ] && break; sleep 2; done
if [ "$PC" = pc ]; then
	nmcli con delete bftest >/dev/null 2>&1
	nmcli con add type wifi ifname wlp5s0 con-name bftest autoconnect no ssid bf-test ipv4.method manual ipv4.addresses 192.168.2.31/24 ipv4.never-default yes ipv6.method disabled >/dev/null
	timeout 45 nmcli --wait 40 con up bftest >/dev/null 2>&1; echo "pc assoc rc=$?" >> $F
fi
sleep 5
timeout 30 $R "wl -i $IF assoclist | sed 's/..:..:..\$/xx:xx:xx/'; [ \$(wl -i $IF assoclist | grep -c assoclist) -gt 0 ] && { echo '-- shm 0x0800-0x085f'; /tmp/bcmpeek 0x20000000 shm 0x0800 0x085e; echo '-- shm 0x0660-0x066f'; /tmp/bcmpeek 0x20000000 shm 0x0660 0x066e; echo '-- shm 0x00b0'; /tmp/bcmpeek 0x20000000 shm 0x00b0 0x00b0; }" >> $F 2>&1
if [ "$PC" = pc ]; then nmcli con down bftest >/dev/null 2>&1; nmcli con delete bftest >/dev/null 2>&1; nmcli --wait 40 con up "Auto PonyWorld 5G" >/dev/null 2>&1
	nmcli --wait 20 con up ddwrt-static >/dev/null 2>&1; fi	# removing bftest takes the cable's prefix route with it
adb -s $PHONE shell "cmd wifi remove-suggestion bf-test" >/dev/null 2>&1
echo "$F: $(grep -c '^0[0-9a-f]\{3\} ' $F) words"
