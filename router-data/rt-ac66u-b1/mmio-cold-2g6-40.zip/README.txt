RT-AC66U B1 (BCM4708, DD-WRT r66396, kernel 4.4.302-rt232-st79, built 2026-10-24), wl 7.14.164.18 (r692288).
wl-mmio-trap 4-4-arm at 474f184 (built against DD-WRT linux-4.4 + .config_northstar_smp, KBUILD_CFLAGS_MODULE=-DMODULE), loaded as:
  insmod wl_mmio_trap.ko autoarm=0 win_phys=<BAR0> win_phys_len=0x8000 fsr_info_fn7=0x805702cc init_mm_addr=0x80576c68 fifo_recs=2097152 poll_secs=10
(addresses found as wl-mmio-trap/4-4-arm/README.md describes; window found = 4 pages / 16 KiB)
Sequence (trapcap*.sh, run.log): nas/wland killed, eth1/eth2 out of br0, rmmod wl; insmod wl (attach NOT traced), trap loaded, then under the trap:
  mark cold-2g6-40 | on | wl ap 1 | wl bw_cap 2g 3 | wl obss_coex 0 | mark chanspec | wl chanspec 6l (0x1808) | mark up | wl up | sleep 10 | mark ssid | wl ssid test-ap | mark bss-up | wl bss up | sleep 10 | mark beaconing | off | mark done
eth1 = 2.4 GHz BCM4360 rev 3 (0001:01:00.0, BAR0 0x08000000), SROM as the board ships (0:rxgains2gelnagaina*=6, trisoa*=13, trelnabypa*=1).
cold-2g6-40-full.bin  the raw stream (emulated=108811 dd=0 foreign=3168 not-ls=0 mismatch=0 cond=0 drops=0)
cold-2g6-40-ops.txt   reverse-tools/mmio2ops.py (default format: the records flag their device offsets), 71508 lines, 7 marks
run.log      the commands and their return codes, the trap's open/status lines
trapcap.sh   the script that ran it, from the PC
