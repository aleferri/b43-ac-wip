#!/bin/bash
# trapcap.sh <name> <if> <win_phys> <chanspec> [pre-up wl args, ';'-separated]: cold wl-mmio-trap capture on DD-WRT
# (Alessio's R7000 sequence: nas/wland killed, radios out of br0, rmmod/insmod wl untraced, trap loaded, then
# mark/on/ap 1/chanspec/up/10s/ssid/bss up/10s/off). Output ~/re/dumps/trap/<name>/{trace.bin,run.log,dmesg.txt}
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@192.168.2.1"
N=$1; IF=$2; WP=$3; CS=$4; PRE=$5; D=~/re/dumps/trap/$N; mkdir -p $D
T="insmod /tmp/wl_mmio_trap.ko autoarm=0 win_phys=$WP win_phys_len=0x8000 fsr_info_fn7=0x805702cc init_mm_addr=0x80576c68 fifo_recs=2097152 poll_secs=10"
timeout 120 $R "rmmod wl_mmio_trap 2>/dev/null; killall nas wland 2>/dev/null; brctl delif br0 eth1 2>/dev/null; brctl delif br0 eth2 2>/dev/null; rmmod wl; insmod /lib/modules/\$(uname -r)/wl.ko; sleep 3; $T; echo trap=\$?; dmesg | grep wl_mmio_trap | tail -1" > $D/run.log 2>&1
grep -q "trap=0" $D/run.log || { echo "$N: trap load failed"; cat $D/run.log; exit 1; }
timeout 300 $R 'cat /proc/wl_mmio_trap' > $D/trace.bin &
RP=$!; sleep 2
P=""; IFS=';'; for c in $PRE; do P="$P echo 'rc $c='\$(wl -i $IF $c >/dev/null 2>&1; echo \$?);"; done; unset IFS
timeout 120 $R "W=/tmp/wlx; M=/proc/wl_mmio_trap; date; echo 'mark $N' > \$M; echo on > \$M; \$W $IF ap 1; echo rc ap=\$?;$P echo 'mark chanspec' > \$M; wl -i $IF chanspec $CS; echo rc chanspec=\$?; echo 'mark up' > \$M; \$W $IF up; echo rc up=\$?; sleep 10; echo 'mark ssid' > \$M; wl -i $IF ssid test-ap; echo rc ssid=\$?; echo 'mark bss-up' > \$M; \$W $IF bss up; echo rc bss=\$?; sleep 10; echo 'mark beaconing' > \$M; echo off > \$M; echo 'mark done' > \$M; wl -i $IF chanspec; date; sleep 3; echo status > \$M; dmesg | grep wl_mmio_trap | tail -2" >> $D/run.log 2>&1
sleep 5; timeout 20 $R 'for p in /proc/[0-9]*; do ls -l $p/fd 2>/dev/null | grep -q wl_mmio_trap && kill ${p#/proc/}; done'; wait $RP 2>/dev/null
timeout 30 $R 'dmesg' > $D/dmesg.txt
echo "$N: $(ls -l $D/trace.bin | awk '{print $5}') bytes; $(grep -o 'emulated=[0-9]* .*' $D/run.log | tail -1)"
