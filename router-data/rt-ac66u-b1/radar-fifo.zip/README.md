# BCM4360 AC-PHY radar FIFO: what the four words of a pulse hold (2026-11-02)

RT-AC66U B1, 5 GHz radio (BCM4360 rev 3, femctrl 3), ch 52/80 (5250-5330 MHz). Known pulses from a HackRF One
(dual-band antenna, next to the router) at 5254-5326 MHz; FIFO data ports PHY 0x0253 / 0x0254 read with single
reads (bcmpeek `fifo`), fill levels 0x0251 / 0x0252, after draining both. Taken under wl 7.14.164.18 (DD-WRT
r66396, radar and 802.11h switched on with WLC_SET_RADAR 243 / WLC_SET_SPECT_MANAGMENT 244: `runs-wl/`) and
under b43 with wl's radar block written live (`runs-b43/`); both give the same entries.

## Arming (what b43 lacks)

wl's radar on, traced (`radar-on-5g52`, ops #10437-#10451, inside the `up` after WLC_SET_RADAR 1; ch 52 and ch 36
bring-ups without radar write none of it):

    025b=001f 0261=0000 0262=0320 0263=0064 0250=ac64 0255=06b8 0256=0030
    025d=0000 0259=7f09 025f=5f88 025c=0001 0260=3206 0264=0141

Radar off is 0250=ac32 0261=0028 0262=0190 0263=0032 (written at every up). Without the block b43's FIFOs stay
empty at any 0x02e4 threshold (0x0020-0x1520 tried, also with pulses); with it they fill. 0x02e4 bits 13:8 change
neither FIFO's sensitivity here (0x04-0x15 at the levels where one FIFO stops detecting).

## One entry per pulse, four 16-bit words

| word | bits | meaning | evidence |
|---|---|---|---|
| w0 | 15:0 | time, bits 27:12 (in 0.2 us units) | steps every 819.2 us = 4096 x 0.2 us |
| w1 | 11:0 | time, bits 11:0 (0.2 us units) | 1000 us PRI -> exactly 5000 between entries, every run |
| w1 | 15:12 | 4-bit value that moves with the pulse's frequency (not monotonic over 5254-5326) and with a chirp (0: 3-4, 5 MHz: 10-11, 20 MHz: 15/0/1 at 5270); fifo 1 stays near 5 | `fq*`, `pw20-chirp*` |
| w2 | 7:0 | pulse width, 0.2 us units | 5/10/20 us -> 25/50(51)/100(101); floor ~9-10 (1-2 us); a 50 us pulse comes as two entries (135 + 106) |
| w2 | 15:8 | 0xff for every CW or chirped pulse at every level; erratic (0x00-0xf9) for noise-like pulses, 0x83-0x86 (fifo 0) / 0xb4-0xb9 (fifo 1) for the AP's own OFDM beacons; what it measures is not established | `noise10`, `idle5s` |
| w3 | 3:0 | time, 1/16 of 0.2 us (12.5 ns) | PRI 1000.05 us: +4 per pulse, the 0.2 us count steps when it wraps; full time `((w0<<12 | w1&0xfff) << 4) | w3&0xf` gives 80003.8 per pulse for 80004 expected, +-4 (one HackRF sample) |
| w3 | 7:4 | 2 on every CW or chirped pulse and on the beacon entries, 0 on most noise-like pulses | `noise10` |
| w3 | 15:8 | always 0 | all runs |

Full timestamp: `t = (w0 << 16 | (w1 & 0xfff) << 4 | (w3 & 0xf))` in 12.5 ns units: 32 bits, wrapping every
2^32 x 12.5 ns = 53.7 s (Alessio's "wraps every 54 s" for w0).

## The two FIFOs

Both see the same pulses at the same times (to the unit); fifo 1 reads widths one unit longer and its w1 nibble
stays near 5. fifo 0 stops detecting at about 6-12 dB more signal than fifo 1 (HackRF amp on: fifo 0 down to VGA
41, fifo 1 to 29), independent of 0x0262/0x0263/0x02e4: most likely two receive chains/antennas, the HackRF being
nearer one of them (not yet proven by moving it).

## Also seen on b43, missing against wl

- **No blanking of its own transmissions**: idle, b43's FIFOs collect two entries 16 units (3.2 us) apart every
  102.4 ms, its beacons; wl's runs show none. Something wl sets around its own TX is missing.
- **The poll stops after the CAC**: `radar_work` reschedules only while `conf->radar_enabled`; after the CAC the
  FIFO levels kept growing, nothing was drained or logged.

## Patterns

`runs-wl/std-*.txt`: ETSI 1-4 and FCC 0-4 (3 bursts each, `iq/*.json` has every pulse sent) under wl at 5270 MHz;
pulse counts match exactly (ETSI 1: 30/30, ETSI 3: 75/75, FCC 0: 54/54, FCC 4: 36/36; FCC 1 saturates the FIFO).
