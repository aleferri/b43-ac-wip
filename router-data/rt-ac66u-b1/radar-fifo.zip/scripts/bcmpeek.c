// Read BCM D11 PHY/radio registers through a PCIe BAR0 window via /dev/mem.
#include <fcntl.h>
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

#define PHY_CTL   0x3fc
#define PHY_DATA  0x3fe
#define RAD_CTL   0x3d8
#define RAD_DATA  0x3da

static volatile uint8_t *bar;
static sigjmp_buf jb;

static void on_bus(int sig) { (void)sig; siglongjmp(jb, 1); }

static uint16_t rd16(unsigned o) { return *(volatile uint16_t *)(bar + o); }
static void wr16(unsigned o, uint16_t v) { *(volatile uint16_t *)(bar + o) = v; }

/* SHM, shared routing: object address 0x160 (32-bit), data 0x164 / 0x166 (16-bit halves) */
static uint16_t shm_r(unsigned off)
{
	*(volatile uint32_t *)(bar + 0x160) = (1u << 16) | (off >> 2);
	return rd16(off & 2 ? 0x166 : 0x164);
}

static void shm_w(unsigned off, uint16_t v)
{
	*(volatile uint32_t *)(bar + 0x160) = (1u << 16) | (off >> 2);
	wr16(off & 2 ? 0x166 : 0x164, v);
}

static int indirect(unsigned ctl, unsigned dat, unsigned reg, uint16_t *out)
{
	uint16_t a, b;
	int i;

	for (i = 0; i < 8; i++) {
		wr16(ctl, reg);
		a = rd16(dat);
		wr16(ctl, reg);
		b = rd16(dat);
		if (a == b) {
			*out = a;
			return 0;
		}
	}
	return -1;
}

int main(int argc, char **argv)
{
	unsigned long base;
	unsigned start, end, r, ctl, dat;
	uint16_t v;
	int fd;
	long tbl = -1;

	if (argc == 4 && !strcmp(argv[2], "tw32")) {
		/* tw32: <bar> tw32 <file of "id off hi lo" lines> : 32-bit table writes, HI then LO */
		FILE *f;
		unsigned id, off, hi, lo, n = 0;
		int fd2 = open(argv[1], O_RDWR | O_SYNC);

		if (fd2 < 0) { perror("open"); return 1; }
		bar = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED, fd2, 0);
		if (bar == MAP_FAILED) { perror("mmap"); return 1; }
		f = fopen(argv[3], "r");
		if (!f) { perror("fopen"); return 1; }
		while (fscanf(f, "%x %x %x %x", &id, &off, &hi, &lo) == 4) {
			wr16(PHY_CTL, 0x0d); wr16(PHY_DATA, id);
			wr16(PHY_CTL, 0x0e); wr16(PHY_DATA, off);
			wr16(PHY_CTL, 0x10); wr16(PHY_DATA, hi);
			wr16(PHY_CTL, 0x0f); wr16(PHY_DATA, lo);
			n++;
		}
		printf("wrote %u\n", n);
		return 0;
	}
	if (argc == 6 && !strcmp(argv[2], "tdump")) {
		/* tdump: <bar> tdump <id-from> <id-to> <len> */
	} else if (argc == 6 && argv[5][0] == 'w') {
		/* write mode: <bar> phy|radio <reg> <val> w */
	} else if (argc != 5) {
		fprintf(stderr, "usage: %s <bar0-phys> phy|radio <start> <end> | fifo <reg> <count>\n", argv[0]);
		return 1;
	}
	base = strtoul(argv[1], NULL, 0);
	start = strtoul(argv[3], NULL, 0);
	end = strtoul(argv[4], NULL, 0);
	if (!strcmp(argv[2], "phy")) {
		ctl = PHY_CTL; dat = PHY_DATA;
	} else if (!strcmp(argv[2], "radio")) {
		ctl = RAD_CTL; dat = RAD_DATA;
	} else if (!strcmp(argv[2], "tdump") || !strcmp(argv[2], "fifo")) {
		ctl = PHY_CTL; dat = PHY_DATA;
	} else if (!strcmp(argv[2], "shm")) {
		ctl = 0x160; dat = 0x164;
	} else if (!strncmp(argv[2], "tbl", 3)) {
		tbl = strtoul(argv[2] + 3, NULL, 16);
		ctl = PHY_CTL; dat = PHY_DATA;
	} else {
		return 1;
	}
	if (argv[1][0] == '/') {
		fd = open(argv[1], O_RDWR | O_SYNC);
		base = 0;
	} else {
		fd = open("/dev/mem", O_RDWR | O_SYNC);
	}
	if (fd < 0) { perror("open"); return 1; }
	bar = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED, fd, base);
	if (bar == MAP_FAILED) { perror("mmap"); return 1; }
	signal(SIGBUS, on_bus);
	if (!strcmp(argv[2], "shm")) {
		if (argc == 6) {
			shm_w(start, end);
			return 0;
		}
		for (r = start & ~1u; r <= end; r += 2)
			printf("%04x %04x\n", r, shm_r(r));
		return 0;
	}
	if (!strcmp(argv[2], "fifo")) {
		/* fifo <reg> <count>: <count> single reads of a PHY data port (a FIFO pops on every read) */
		for (r = 0; r < end; r++) {
			wr16(ctl, start);
			printf("%04x\n", rd16(dat));
		}
		return 0;
	}
	if (!strcmp(argv[2], "tdump")) {
		unsigned id, len = strtoul(argv[5], NULL, 0);

		for (id = start; id <= end; id++) {
			for (r = 0; r < len; r++) {
				uint16_t a[3] = { 0 }, b[3] = { 0 };
				volatile int stage = 0;
				int k;

				if (sigsetjmp(jb, 1)) {
					printf("%02x %04x ABORT@%d\n", id, r, stage);
					continue;
				}
				for (k = 0; k < 2; k++) {
					uint16_t *v = k ? b : a;

					wr16(PHY_CTL, 0x0d); wr16(PHY_DATA, id);
					wr16(PHY_CTL, 0x0e); wr16(PHY_DATA, r);
					stage = 1;
					wr16(PHY_CTL, 0x0f); v[0] = rd16(PHY_DATA);
					stage = 2;
					wr16(PHY_CTL, 0x10); v[1] = rd16(PHY_DATA);
					stage = 0;
				}
				printf("%02x %04x %04x %04x%s\n", id, r, a[0], a[1],
				       memcmp(a, b, sizeof(a)) ? " RACE" : "");
			}
		}
		return 0;
	}
	if (argc == 6 && tbl >= 0) {
		wr16(ctl, 0x0d); wr16(dat, tbl);
		wr16(ctl, 0x0e); wr16(dat, start);
		wr16(ctl, 0x0f); wr16(dat, end);
		return 0;
	}
	if (argc == 6) {
		wr16(ctl, start);
		wr16(dat, end);
		return 0;
	}
	for (r = start; r <= end; r++) {
		if (sigsetjmp(jb, 1)) {
			printf("%04x ----\n", r);
			continue;
		}
		if (tbl >= 0) {
			uint16_t lo;
			wr16(ctl, 0x0d); wr16(dat, tbl);
			wr16(ctl, 0x0e); wr16(dat, r);
			wr16(ctl, 0x0f); lo = rd16(dat);
			wr16(ctl, 0x10); v = rd16(dat);
			printf("%04x %04x %04x\n", r, v, lo);
			continue;
		}
		if (indirect(ctl, dat, r, &v))
			printf("%04x ????\n", r);
		else
			printf("%04x %04x\n", r, v);
	}
	return 0;
}
