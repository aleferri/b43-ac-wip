#!/bin/bash
# fifo_idle.sh <name> <seconds>: drain both radar FIFOs, wait without transmitting, read them back (runs-b43/<name>.txt)
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@192.168.2.1"
B=/sys/bus/pci/devices/${BDEV:-0001:01:00.0}/resource0; D=$(dirname "$0")/runs-b43; mkdir -p "$D"
rd='for f in 0 1; do lv=$(/tmp/bcmpeek '$B' phy 0x025$((1+f)) 0x025$((1+f)) | awk "{print \$2}"); /tmp/bcmpeek '$B' fifo 0x025$((3+f)) $((0x$lv)) | sed "s/^/$f /"; done'
$R "$rd" > /dev/null; sleep "$2"
$R "echo \$(/tmp/bcmpeek $B phy 0x0251 0x0251 | awk '{print \$2}') \$(/tmp/bcmpeek $B phy 0x0252 0x0252 | awk '{print \$2}'); $rd" > "$D/$1.txt"
echo "$1: levels $(head -1 "$D/$1.txt")"
