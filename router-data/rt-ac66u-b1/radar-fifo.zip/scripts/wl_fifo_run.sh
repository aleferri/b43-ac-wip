#!/bin/bash
# wl_fifo_run.sh <name> <file.iq> [gain] [amp]: under DD-WRT wl with radar on (eth2, ch52/80), drain both radar FIFOs,
# play the pattern at 5290 MHz, read back every word of both FIFOs (single reads, bcmpeek fifo) into runs-wl/<name>.txt
# ("level0 level1" line, then "<fifo> <word>" lines), with the pattern's JSON beside it.
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@192.168.2.1"
N=$1; F=$2; G=${3:-47}; A=${4:-1}; D=$(dirname "$0")/${OUT:-runs-wl}; mkdir -p "$D"; B=/sys/bus/pci/devices/${BDEV:-0002:01:00.0}/resource0
rd='for f in 0 1; do lv=$(/tmp/bcmpeek '$B' phy 0x025$((1+f)) 0x025$((1+f)) | awk "{print \$2}"); /tmp/bcmpeek '$B' fifo 0x025$((3+f)) $((0x$lv)) | sed "s/^/$f /"; done'
$R "$rd" > /dev/null
AMP=$A FORCE=1 "$(dirname "$0")/radar_tx.sh" "$F" "${FREQ:-5290}" "$G" > /dev/null || { echo "tx refused/failed"; exit 1; }
$R "echo \$(/tmp/bcmpeek $B phy 0x0251 0x0251 | awk '{print \$2}') \$(/tmp/bcmpeek $B phy 0x0252 0x0252 | awk '{print \$2}'); $rd" > "$D/$N.txt"
cp "$F.json" "$D/$N.json" 2>/dev/null
echo "$N: levels $(head -1 "$D/$N.txt"); words fifo0 $(grep -c '^0 ' "$D/$N.txt") fifo1 $(grep -c '^1 ' "$D/$N.txt")"
