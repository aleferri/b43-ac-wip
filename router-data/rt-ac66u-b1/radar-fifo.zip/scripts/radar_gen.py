#!/usr/bin/env python3
"""radar_gen.py: radar test bursts as HackRF IQ (interleaved int8, complex baseband).

  radar_gen.py OUT.iq --type etsi1|etsi2|etsi3|etsi4|fcc0|fcc1|fcc2|fcc3|fcc4|fcc5
  radar_gen.py OUT.iq --pw 2 --pri 1000 --n 18 [--chirp 0] [--bursts 1] [--gap 0.2]

Pulses are CW (or a linear chirp of --chirp MHz across the pulse) at the tuned centre frequency,
amplitude --amp (0..1 of int8 full scale), with --lead seconds of silence before and after. The
pattern parameters follow FCC KDB 905462 D02 (types 0-5) and ETSI EN 301 893 v2.2.1 Table D.4
(types 1-4); one value per range is drawn with --seed so a run can be repeated. Writes OUT.iq and
OUT.json (every pulse's start time, width, chirp), the reference for decoding the b43 radar FIFO words.
"""
import argparse, json, math, random, sys
import numpy as np

FS = 20e6

def pattern(kind, rnd):
    """-> (list of bursts, each a list of (t_us, pw_us, chirp_mhz)), description"""
    def train(pw, pri, n, chirp=0.0, t0=0.0):
        return [(t0 + i * pri, pw, chirp) for i in range(n)]
    if kind == 'fcc0':
        return [train(1, 1428, 18)], 'FCC type 0: 1 us, PRI 1428 us, 18 pulses'
    if kind == 'fcc1':
        pri = rnd.choice(range(518, 3067))
        n = math.ceil((1 / 360) * (19e6 / pri))
        return [train(1, pri, n)], f'FCC type 1: 1 us, PRI {pri} us, {n} pulses'
    if kind == 'fcc2':
        pw, pri, n = rnd.uniform(1, 5), rnd.uniform(150, 230), rnd.randint(23, 29)
        return [train(pw, pri, n)], f'FCC type 2: {pw:.1f} us, PRI {pri:.0f} us, {n} pulses'
    if kind == 'fcc3':
        pw, pri, n = rnd.uniform(6, 10), rnd.uniform(200, 500), rnd.randint(16, 18)
        return [train(pw, pri, n)], f'FCC type 3: {pw:.1f} us, PRI {pri:.0f} us, {n} pulses'
    if kind == 'fcc4':
        pw, pri, n = rnd.uniform(11, 20), rnd.uniform(200, 500), rnd.randint(12, 16)
        return [train(pw, pri, n)], f'FCC type 4: {pw:.1f} us, PRI {pri:.0f} us, {n} pulses'
    if kind == 'fcc5':
        # long pulse: 8-20 bursts over 12 s, 1-3 pulses of 50-100 us, chirp 5-20 MHz; shortened to 3 s here
        nb = rnd.randint(8, 20); chirp = rnd.uniform(5, 20); bursts = []
        for b in range(nb):
            t = b * (3e6 / nb) + rnd.uniform(0, 3e6 / nb / 2)
            k = rnd.randint(1, 3)
            bursts.append([(t + j * rnd.uniform(1000, 2000), rnd.uniform(50, 100), chirp) for j in range(k)])
        return [[p for b in bursts for p in b]], f'FCC type 5 (3 s): {nb} bursts, chirp {chirp:.1f} MHz'
    if kind.startswith('etsi'):
        pw_rng, prf_rng, n, chirp = {
            'etsi1': ((0.5, 5), (200, 1000), 10, 0),
            'etsi2': ((0.5, 15), (200, 1600), 15, 0),
            'etsi3': ((0.5, 15), (2300, 4000), 25, 0),
            'etsi4': ((20, 30), (2000, 4000), 20, 2.5),
        }[kind]
        pw, prf = rnd.uniform(*pw_rng), rnd.uniform(*prf_rng)
        return [train(pw, 1e6 / prf, n, chirp)], f'ETSI {kind[4:]}: {pw:.1f} us, PRF {prf:.0f} Hz, {n} pulses'
    sys.exit(f'unknown type {kind}')

def main():
    a = argparse.ArgumentParser()
    a.add_argument('out')
    a.add_argument('--type')
    a.add_argument('--pw', type=float); a.add_argument('--pri', type=float); a.add_argument('--n', type=int)
    a.add_argument('--chirp', type=float, default=0.0, help='MHz swept across each pulse')
    a.add_argument('--bursts', type=int, default=1); a.add_argument('--gap', type=float, default=0.2, help='s between bursts')
    a.add_argument('--amp', type=float, default=0.7); a.add_argument('--lead', type=float, default=0.05)
    a.add_argument('--seed', type=int, default=1)
    o = a.parse_args()
    rnd = random.Random(o.seed)
    if o.type:
        trains, desc = pattern(o.type, rnd)
    elif o.pw and o.pri and o.n:
        trains = [[(i * o.pri, o.pw, o.chirp) for i in range(o.n)]]
        desc = f'custom: {o.pw} us, PRI {o.pri} us, {o.n} pulses, chirp {o.chirp} MHz'
    else:
        sys.exit('give --type or --pw/--pri/--n')
    pulses = []
    t_us = o.lead * 1e6
    for b in range(o.bursts):
        for tr in trains:
            for (t, pw, ch) in tr:
                pulses.append((t_us + t, pw, ch))
            t_us += tr[-1][0] + tr[-1][1] + o.gap * 1e6
    total = int((t_us + o.lead * 1e6) * 1e-6 * FS)
    iq = np.zeros(total, dtype=np.complex64)
    for (t, pw, ch) in pulses:
        s, n = int(t * 1e-6 * FS), max(1, int(pw * 1e-6 * FS))
        k = np.arange(n) / FS
        if ch:
            bw = ch * 1e6; T = n / FS
            ph = 2 * np.pi * (-bw / 2 * k + bw / (2 * T) * k * k)
        else:
            ph = np.zeros(n)
        iq[s:s + n] = o.amp * np.exp(1j * ph)
    out = np.empty(2 * total, dtype=np.int8)
    out[0::2] = np.clip(np.round(iq.real * 127), -127, 127)
    out[1::2] = np.clip(np.round(iq.imag * 127), -127, 127)
    out.tofile(o.out)
    json.dump({'desc': desc, 'fs': FS, 'bursts': o.bursts, 'seed': o.seed,
               'pulses': [{'t_us': round(t, 3), 'pw_us': round(pw, 3), 'chirp_mhz': ch} for (t, pw, ch) in pulses]},
              open(o.out + '.json', 'w'), indent=1)
    print(f'{desc}; {len(pulses)} pulses, {total / FS:.3f} s, {o.out}')

if __name__ == '__main__':
    main()
