#!/usr/bin/env python3
# wl_fifo_fit.py runs-wl/<name>.txt ...: decode the 4-word radar FIFO entries against the sent pattern (JSON beside).
import json, sys, statistics as st
for f in sys.argv[1:]:
    L = open(f).read().split('\n'); rows = [l.split() for l in L[1:] if l.strip()]
    pat = json.load(open(f[:-4] + '.json'))
    for fifo in ('0', '1'):
        w = [int(x[1], 16) for x in rows if x[0] == fifo]
        e = [w[i:i + 4] for i in range(0, len(w) - 3, 4)]
        if not e: continue
        ts = [(a << 16) | b for a, b, c, d in e]
        dts = [(y - x) & 0xffffffff for x, y in zip(ts, ts[1:])]
        sent = pat['pulses']; pri = [b['t_us'] - a['t_us'] for a, b in zip(sent, sent[1:])]
        print(f"{f.split('/')[-1]} fifo{fifo}: {len(e)} entries for {len(sent)} pulses sent ({pat['desc']})")
        print('  dts(w0:w1):', dts[:16])
        print('  w1 low12 :', [x[1] & 0xfff for x in e[:12]], ' w1 hi4:', [x[1] >> 12 for x in e[:12]])
        print('  w2:', sorted(set(x[2] for x in e)), ' w3 range: %02x-%02x' % (min(x[3] for x in e), max(x[3] for x in e)))
        if pri: print('  sent PRI us median %.1f' % st.median(pri))
