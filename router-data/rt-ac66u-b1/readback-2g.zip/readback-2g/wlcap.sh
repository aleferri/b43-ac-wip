#!/bin/bash
# wlcap.sh <pci-dev> <name>: dump wl PHY regs, radio regs, PHY tables into ~/re/dumps/wl/<name>
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@192.168.2.1"
B=/sys/bus/pci/devices/$1/resource0; N=$2; O=~/re/dumps/wl/$N; mkdir -p $O; rm -f $O/tables.txt
cat ~/re/tools/peek/bcmpeek | $R 'cat > /tmp/bcmpeek; chmod +x /tmp/bcmpeek'
cat ~/re/test/phyranges | $R 'cat > /tmp/phyranges'
timeout 120 $R "while read a b; do /tmp/bcmpeek $B phy \$a \$b; done < /tmp/phyranges" > $O/phy.txt
timeout 60 $R "/tmp/bcmpeek $B radio 0 0x7ff" > $O/radio.txt
for id in 0x01 0x02 0x03 0x04 0x05 0x07 0x0a 0x0b 0x0c 0x0e 0x10 0x11 0x14 0x15 0x20 0x21 0x40 0x41 0x42 0x44 0x45 0x47 0x48 0x60 0x61 0x62 0x64 0x65 0x67 0x68 0x80 0x81 0x82 0x84 0x85 0x87 0x88; do
	timeout 30 $R "/tmp/bcmpeek $B tdump $id $id 0x200" >> $O/tables.txt || break
done
echo "$N: phy=$(wc -l < $O/phy.txt) radio=$(wc -l < $O/radio.txt) tbl=$(wc -l < $O/tables.txt)"
