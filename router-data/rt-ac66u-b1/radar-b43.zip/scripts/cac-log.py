#!/usr/bin/env python3
# TEST ONLY: log the CAC gate from inside b43 (main.c): every config call's channel, cac/radar_enabled/retune and
# MACCTL, and each gate open/close with MACCTL after it.
import sys
p = sys.argv[1]; s = open(p).read()
old = "\t\tif (ac && dev->cac_pending != cac_was)\n\t\t\tb43_ac_cac_match_gate(dev, !dev->cac_pending);\n"
assert s.count(old) == 1
s = s.replace(old, old + "\t\tif (ac)\n\t\t\tprintk(KERN_INFO \"b43-cac config ch%u w%d radar_enabled %d cac_pending %d radar_arm %d retune %d macctl %08x\\n\", conf->chandef.chan->hw_value, conf->chandef.width, conf->radar_enabled, dev->cac_pending, dev->radar_arm, retune, b43_read32(dev, B43_MMIO_MACCTL));\n")
old = "\t/* The interface may have come up before the check started. */\n"
assert s.count(old) == 1
s = s.replace(old, "\tprintk(KERN_INFO \"b43-cac gate close\\n\");\n" + old)
old = "\t\tif (dev->phy.ops->cac_done)\n\t\t\tdev->phy.ops->cac_done(dev);\n\t\treturn;\n"
assert s.count(old) == 1
s = s.replace(old, "\t\tif (dev->phy.ops->cac_done)\n\t\t\tdev->phy.ops->cac_done(dev);\n\t\tprintk(KERN_INFO \"b43-cac gate open macctl %08x\\n\", b43_read32(dev, B43_MMIO_MACCTL));\n\t\treturn;\n")
open(p, 'w').write(s); print('applied')
