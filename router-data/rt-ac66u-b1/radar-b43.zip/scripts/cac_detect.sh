#!/bin/bash
# cac_detect.sh <name> <pattern.iq> [freq MHz] [gain]: restart the AC66U's Wi-Fi so hostapd runs the channel availability
# check on the configured radar channel (ch 52/80), play the pattern 20 s into the check (radar_tx.sh, amp on), and
# collect the driver's radar lines and hostapd's DFS events into runs/<name>/.
R="ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o BatchMode=yes -o ConnectTimeout=5 root@${ROUTER:-192.168.2.1}"
N=$1; F=$2; MHZ=${3:-5270}; G=${4:-35}; D=$(dirname "$0"); O=$D/runs/$N; mkdir -p "$O"
m="cacmark-$N-$(date +%s)"; $R "logger -t dfs $m; echo $m > /dev/kmsg; wifi"
for i in $(seq 1 30); do $R "logread | sed -n '/$m/,\$p' | grep -q 'DFS-CAC-START'" && break; sleep 2; done
$R "logread | sed -n '/$m/,\$p' | grep 'DFS-CAC-START'" | tail -1 > "$O/cac-start.txt"
[ -s "$O/cac-start.txt" ] || { echo "$N: no CAC started"; exit 1; }
sleep 20
AMP=1 FORCE=1 "$D/radar_tx.sh" "$F" "$MHZ" "$G" > "$O/tx.txt" 2>&1; echo "tx rc=$?" >> "$O/tx.txt"
sleep 10
$R "logread | sed -n '/$m/,\$p' | grep -E 'DFS-|AP-ENABLED|AP-DISABLED|CSA'; dmesg | sed -n '/$m/,\$p' | grep 'radar:'" > "$O/router.log"
cp "$F.json" "$O/pattern.json" 2>/dev/null
cat "$O/cac-start.txt" "$O/router.log" | cut -c1-170
