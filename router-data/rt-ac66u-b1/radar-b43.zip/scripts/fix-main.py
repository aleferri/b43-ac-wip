import sys; p=sys.argv[1]; s=open(p).read()
old='''	if (likely(b43_status(dev) == B43_STAT_STARTED) &&
	    wl->hw->conf.radar_enabled) {
		/*
		 * The PHY counts pulses, it does not match them against the
		 * radar types (b43_phy_ac_radar_pulse()).
		 */
		if (dev->phy.ops->radar_poll(dev))
			ieee80211_radar_detected(wl->hw, NULL);'''
new='''	if (likely(b43_status(dev) == B43_STAT_STARTED) && dev->radar_arm) {
		/* The PHY matches the pulses against the radar types. */
		if (dev->phy.ops->radar_poll(dev) &&
		    wl->hw->conf.radar_enabled)
			ieee80211_radar_detected(wl->hw, NULL);'''
assert s.count(old)==1; open(p,'w').write(s.replace(old,new))
