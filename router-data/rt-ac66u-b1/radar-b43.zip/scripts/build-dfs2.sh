#!/bin/bash
# build-dfs2.sh OUT.ko: b43.ko for the AC66U from the b43-ac-wip WORKING TREE (uncommitted) with CONFIG_B43_DFS:
# backports prepared from ~/openwrt's current snapshot, then b43-ac-wip's b43/ copied over it (CONFIG_B43 ->
# CPTCFG_B43, as scripts/phase1-to-openwrt.sh filters it). Only build_dir changes; broadcom.mk is restored.
set -e
OUT=$1; SRC=/home/tossu/re/b43-ac-wip/b43
cd ~/openwrt
M=package/kernel/mac80211/broadcom.mk
trap 'git checkout -- $M' EXIT
sed -i 's/^config-$(CONFIG_PACKAGE_B43_PHY_AC) += B43_PHY_AC$/&\nconfig-$(CONFIG_PACKAGE_B43_PHY_AC) += B43_DFS/' $M
grep -q "+= B43_DFS" $M
make package/kernel/mac80211/clean >/dev/null 2>&1
make package/kernel/mac80211/prepare > ~/re/release/ci/dfs2-prep.log 2>&1
D=build_dir/target-arm_cortex-a9_musl_eabi/linux-bcm53xx_generic/mac80211-regular/backports-7.2
B=$D/drivers/net/wireless/broadcom/b43
# The prepared files carry backports' API edits: apply this branch's change on them as a patch, the new files whole.
git -C /home/tossu/re/b43-ac-wip diff origin/main -- b43/ ':!b43/radar_ac.c' ':!b43/radar_ac.h' |
	sed -e 's/CONFIG_B43/CPTCFG_B43/g' -e 's#^\(---\|+++\) \([ab]\)/b43/#\1 \2/#' > /home/tossu/re/dfs/dfs.patch
patch -d $B -p1 --no-backup-if-mismatch < /home/tossu/re/dfs/dfs.patch || true
# the radar handler's hunk: backports' ieee80211_radar_detected() takes a chanctx
[ -f $B/main.c.rej ] && python3 -I /home/tossu/re/dfs/fix-main.py $B/main.c && rm $B/main.c.rej
ls $B/*.rej 2>/dev/null && exit 1
[ -n "$RADAR_LOG" ] && python3 -I /home/tossu/re/dfs/radar-log2.py $B/phy_ac.c
for f in radar_ac.c radar_ac.h; do sed -e 's/CONFIG_B43/CPTCFG_B43/g' $SRC/$f > $B/$f; done
grep -q radar_ac.o $B/Makefile
grep -q '^B43_DFS=' $D/local-symbols || sed -i '/^B43_PHY_AC=/a B43_DFS=' $D/local-symbols
make package/kernel/mac80211/compile -j8 V=s > ~/re/release/ci/dfs2-build.log 2>&1 || { grep -E "error|warning:" ~/re/release/ci/dfs2-build.log | head -30; exit 1; }
grep -E "radar_ac|phy_ac\.c|main\.c" ~/re/release/ci/dfs2-build.log | grep -i "warning" | head
grep -q "define CPTCFG_B43_DFS 1" $D/backport-include/backport/autoconf.h
grep -q radar_arm $B/main.c
cp $B/b43.ko "$OUT"
echo "built $OUT"; ls -la "$OUT"
