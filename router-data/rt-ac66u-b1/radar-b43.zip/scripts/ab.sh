B=/sys/bus/pci/devices/0001:01:00.0/resource0
P=/tmp/bcmpeek
drain() { for f in 0 1; do lv=$($P $B phy 0x025$((1+f)) 0x025$((1+f)) | awk '{print $2}'); $P $B fifo 0x025$((3+f)) $((0x$lv)) >/dev/null; done; }
lv() { echo "$1: $($P $B phy 0x0251 0x0252 | tr '\n' ' ')"; }
idle() { drain; sleep 5; lv "$1"; }
echo "shm 5e/66: $($P $B shm 0x5e 0x5e) | $($P $B shm 0x66 0x66)"
idle base
for kv in 025b=001f 0261=0000 0262=0320 0263=0064 0250=ac64 0255=06b8 0256=0030 025d=0000 0259=7f09 025f=5f88 025c=0001 0260=3206 0264=0141; do $P $B phy 0x${kv%=*} 0x${kv#*=} w >/dev/null; done
idle phyblock
idle phyblock2
h=$($P $B shm 0x5e 0x5e | awk '{print $2}')
$P $B shm 0x66 0x30 w; $P $B shm 0x5e $(printf 0x%x $((0x$h | 0x2000))) w
echo "shm 5e/66: $($P $B shm 0x5e 0x5e) | $($P $B shm 0x66 0x66)"
idle phy+shm
idle phy+shm2
$P $B shm 0x66 0x30 w; $P $B shm 0x5e 0x$h w
idle phy+shm66only
$P $B shm 0x66 0 w; $P $B shm 0x5e $(printf 0x%x $((0x$h | 0x2000))) w
idle phy+hf2000only
