# RT-AC66U B1: b43's radar detector against known pulses (2026-11-03)

RT-AC66U B1, 5 GHz radio (BCM4360 rev 3, femctrl 3), OpenWrt r38009+3 with b43 from b43-ac-wip c6ecb0c plus the
radar change (`b43_phy_ac_radar_arm()`, `radar_ac.c`), `CONFIG_B43_DFS`, regulatory domain FI (ETSI). AP on
ch 52/80 (5250-5330 MHz, centre 5290). Pulses from a HackRF One (`scripts/radar_gen.py`, `scripts/radar_tx.sh`,
amp on, TX VGA gain in the file names), an improvised ~12 cm wire antenna on top of the router.

## Arming and blanking

The driver arms the detector with `wl`'s radar-on block (`radar-fifo.zip`, `radar-on-5g52`): read back on the
running AP, PHY 0x0250-0x0264 equal `wl`'s radar-on read-back, SHM 0x0066 = 0x0030, HOSTF1 = 0x2100.

Blanking A/B on b43 at ch 36, idle, 5 s, both FIFO levels in words (`scripts/ab.sh`, writes through `/dev/mem`):

| state | fifo 0 | fifo 1 |
|---|---|---|
| no radar block | 0 | 0 |
| PHY block | 0x18c (the beacon, two entries every 102.4 ms) | 0x0c |
| PHY block + SHM 0x0066=0x0030 + HOSTF1 bit 13 | 0 / 0 (two runs) | 8 / 0 |
| PHY block + SHM 0x0066 only | 0x188 | 0x08 |
| PHY block + HOSTF1 bit 13, SHM 0x0066 = 0 | 0x5fc (full) | 0x5fc (full) |

## `sweep-5270/`: w2 15:8 against level

Every FIFO entry the driver drained (test build, `scripts/radar-log2.py`: one line per entry, `radar <fifo> <w0>
<w1> <w2> <w3> lvl <fill level>`), for 1 us, 1.1 us (ETSI 1), 5 us and 20 us CW pulses, 20 us chirped by 20 MHz
(`pw20-ch20`) and noise bursts (`noise10`, 10 us every 1000 us), at 5270 MHz, gain 15-47; the sent pattern beside
each (`.json`). Entries of 0.6 us and wider: w2 15:8 is 0xc0 or more on 1197 of 1205 of the pulse runs' entries
(the 8 others are entries beyond the pulses sent) from the level where fifo 1 first sees them (gain 23) up, and on
2 of 138 of noise10's.

## `dc-5290/`: the centre of the channel

5 us and 1.1 us pulses at gain 35 stepped across the 80 MHz channel's centre (5280-5300 MHz). At 5290 MHz the 5 us
pulses come as two 0.2 us entries at their edges (none 0.6 us or wider) and the 1.1 us ones with w2 15:8 at
0x4c-0x9d; at 5289 and 5291 MHz, and further out, as anywhere else.

## `inservice/`

ETSI 1 (1.1 us, PRF 878 Hz, 3 bursts of 10) at 5270 MHz, gain 35, 13 s after the channel availability check ended:
`radar: ETSI 1 pulses`, hostapd `DFS-RADAR-DETECTED`, new channel 149 (b43 has no CSA: hostapd restarts the AP).

## `cac/`

FCC 0 (1 us, PRI 1428 us, 3 bursts of 18) at 5270 MHz, gain 35, 20 s into the channel availability check
(`scripts/cac_detect.sh`): `radar: ETSI 1 pulses` (ETSI 1's range holds FCC 0 and is matched first), hostapd
`DFS-CAC-COMPLETED success=0`, `DFS-RADAR-DETECTED`, new channel 149.

## `cac-gate/`

The check's gate logged from inside b43 (test build, `scripts/cac-log.py`: every config call's channel, width,
`conf->radar_enabled`, `cac_pending`, `radar_arm`, retune and MACCTL; the gate's close and open). `before.txt`, the
gate keyed on `conf->radar_enabled`: it reads 0 on every call through the check, the gate never closes, MACCTL keeps
B43_MACCTL_AP (0x00040000). `fixed.txt`, the gate keyed on an AP on a radar channel that does not beacon yet:
closed through the check (MACCTL 0x44120402), opened by the beacon (0x44160403).

## Soak

Client traffic (rtl8821ae, iperf3 TCP, 4 streams) on ch 52/80 with the detector armed: 3 x 55 s each way, 165-170
up / 140-147 down Mbit/s, and 3 x ~130 s up at 172 Mbit/s: no radar reported, no DFS event.
