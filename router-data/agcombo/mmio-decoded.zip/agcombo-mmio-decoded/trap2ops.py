#!/usr/bin/env python3
"""Testo di decode-wl-mmio.py -> op di mmio2ops.Decoder (nessuna modifica al repo)."""
import re, sys
sys.path.insert(0, "/home/claude/b43-ac-wip/reverse-tools")
from mmio2ops import Decoder, Op

LINE = re.compile(r"\s*([\d.]+)\s+#(\d+)\s+cpu\d+\s+MMIO\.(RD|WR)\s+addr=(\S+)\s+val=(\S+)\s+w=(\d+)")

def ops(path):
    for l in open(path):
        m = LINE.match(l)
        if m:
            ts, _, k, a, v, w = m.groups()
            off, width = int(a, 16), int(w)
            # MIPS BE: wl accede ai registri a 16 bit su (r ^ 2); il trap
            # registra l'offset lato CPU, il device vede l'altra meta' della word.
            if width == 2 and "--no-swap" not in sys.argv:
                off ^= 2
            yield Op(float(ts), "R" if k == "RD" else "W", width, off, int(v, 16))

dec = Decoder(mark_windows="--mark-windows" in sys.argv)
n = 0
for ts, line in dec.decode(ops(sys.argv[1])):
    if line.startswith("REG.RD off=0x03e0") and "--keep-flush" not in sys.argv:
        continue
    n += 1
    print(f"{ts:15.6f} #{n:<8} cpu0 {line}")
